"""Robert Lin"""  # your name
"roblin"  # your NetID
"110875190"  # your SBU ID number
"CSE 101"  # CSE 101
"Homework 3"  # Homework 3


# Part I
def frog(mood, actions):
    current_mood = mood
    for i in actions:
        if i == 'play':
            current_mood += 3
        if i == 'eat' and current_mood >= .5 * mood:
            current_mood += 1
        elif i == 'eat' and current_mood < .5 * mood:
            current_mood -= 2
        if i == 'read' and current_mood >= .75 * mood:
            current_mood -= 3
        elif i == 'read' and current_mood < .75 * mood:
            current_mood -= 4
        if i == 'work':
            current_mood -= 5
        current_mood -= 1
        if current_mood <= 0:
            return 0
    return current_mood


# Part II
def pacman(line):
    k = []  # contains list of uppercase and lowercase letters
    j = ['G', 'g', 'H', 'h', 'O', 'o', 'S', 's', 'T', 't']  # Ghost
    isstop = False
    for i in line:
        if isstop:
            k.append(i)
        else:
            if i not in j:
                k.append('_')
            else:
                if len(k) != 0:
                    k.pop()
                k.append('<')
                k.append(i)
                isstop = True
    if isstop == False:
        k.append('<')
    return k


# Part III
def brackets(expr):
    L = []
    left = ['(', '{', '[']
    right = [')', '}', ']']
    for i in expr:
        if i in left:
            L.append(i)
        elif i in right and len(L) == 0:
            return "error"
        elif i == ')' and L[len(L)-1] == '(':
            L.pop()
        elif i == '}' and L[len(L)-1] == '{':
            L.pop()
        elif i == ']' and L[len(L)-1] == '[':
            L.pop()
        else:
            return L
    return L


# Part IV
def hail_length(n):
    i = 1
    while n > 1:
        if n % 2 == 0:
            n //= 2
        else:
            n *= 3
            n += 1
        i += 1
    return i


def siblings(length, maximum):
    result = []
    for i in range(1, maximum+1):
        if hail_length(i) == length:
            result.append(i)
    return result


# Part V
def vampire_hunt(humans, vampires, hunters):
    i = humans
    v = vampires
    h = hunters
    while i > 0 and v > 0:
        v -= h
        if v <= 0:
            return [i, 0]
        if v <= i:
            i -= v
            v *= 2
        else:
            humansBefore = i
            i -= v
            v += humansBefore
        if i <= 0:
            return [0, v]
    return [i, v]
