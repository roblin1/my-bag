package Dessert_Cafe;

public class Cake extends Dessert{
    // abstract variables are initialized to Cake's name & layers
    Cake(String type, int layers) {  // Cake constructor
        name = type;
        cost = 15 + (2 * layers);
    }

    // returns Cake's name or cost
    @Override
    String getName() {
        return name;
    }

    @Override
    int getCost() {
        return cost;
    }
}
