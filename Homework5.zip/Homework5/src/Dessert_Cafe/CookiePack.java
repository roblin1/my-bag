package Dessert_Cafe;

public class CookiePack extends Dessert {
    // abstract variables are initialized to CookiePack's name, quantity, and price
    CookiePack(String type, int num, int cookiePrice) { // CookiePack constructor
        name = type;
        cost = num * cookiePrice;
    }

    // returns CookiePack's name or cost
    @Override
    String getName() {
        return name;
    }

    @Override
    int getCost() {
        return cost;
    }
}
