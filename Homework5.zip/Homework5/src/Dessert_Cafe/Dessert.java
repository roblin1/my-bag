package Dessert_Cafe;

abstract class Dessert { // data members are package level visibility
    String name; // name of dessert
    int cost; // cost of dessert

    // returns name or cost of dessert
    abstract String getName();
    abstract int getCost();
}
