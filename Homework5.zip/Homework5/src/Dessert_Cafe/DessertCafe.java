package Dessert_Cafe;
// Robert Lin
// 110875190
// CSE 114
// Homework #5
import java.util.ArrayList;
public class DessertCafe {
    public static void main(String[] args ) {
        ArrayList<Dessert> desserts = new ArrayList<Dessert>(); // Dessert arraylist

        // takes in parameters of the Cake class constructor (String type, int layers)
        Cake c1 = new Cake("Strawberry Shortcake", 5);
        Cake c2 = new Cake("Red Velvet", 3);

        CookiePack cp1 = new CookiePack("Chocolate Chip", 2, 15);
        CookiePack cp2 = new CookiePack("Oatmeal Raisin", 3, 11);

        IceCream ic1 = new IceCream("Cookies & Cream", 6);
        IceCream ic2 = new IceCream("Mint Chocolate Chip", 4);

        Sundae s1 = new Sundae("Chocolate Stout Waffle", 5); // 15 (adds the static price 10)
        Sundae s2 = new Sundae("Raspberry Rose", 7); // 17 (adds the static price 10)

        // adds objects to arraylist
        desserts.add(c1);
        desserts.add(c2);
        desserts.add(cp1);
        desserts.add(cp2);
        desserts.add(ic1);
        desserts.add(ic2);
        desserts.add(s1);
        desserts.add(s2);

        for (int i = 0; i < desserts.size(); i++) {
            if (i == 0) { // indexes [0 - 2] is cakes
                System.out.println("\nDessert Café: Cake");

            } else if (i == 2) { // indexes [2 - 4] is cookies
                System.out.println("\nDessert Café: CookiePack");

            } else if (i == 4) { // indexes [4 -6] is ice cream
                System.out.println("\nDessert Café: IceCream");

            } else if (i == 6) { // index [6 - 8] is sundaes
                System.out.println("\nDessert Café: Sundae");
            }

            System.out.println("Name: " + desserts.get(i).getName());
            System.out.println("Cost: " + desserts.get(i).getCost());
        }

    }
}
