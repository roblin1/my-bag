package Dessert_Cafe;

public class IceCream extends Dessert {
    static int startCost = 10; // to share the starting cost w/ Sundae class

    // abstract variables are initialized to IceCream's name & cost
    IceCream(String type, int iceCost) { // IceCream constructor
        name = type;
        cost = iceCost;
    }

    // returns IceCream's name & cost
    @Override
    String getName() {
        return name;
    }

    @Override
     int getCost() {
        return cost; // it's not startCost bc it's static & will give the wrong #
     }
}
