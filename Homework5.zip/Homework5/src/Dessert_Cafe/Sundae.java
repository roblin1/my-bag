package Dessert_Cafe;

public class Sundae extends IceCream {
    /* no default constructor in IceCream bc constructors aren't inherited
       calling super(type, topping) will invoke the parent class (Ice Cream) constructor
     */
    Sundae(String type, int topping) { // Sundae constructor
        super(type, topping);
        name = type;
        cost = IceCream.startCost + topping; // starting price of IceCream (static) + topping
    }

    // returns Sundae's name & cost
    @Override
    String getName() {
        return name;
    }

    @Override
    int getCost() {
        return cost;
    }
}
