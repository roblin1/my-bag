package Wolfie_Shop;

public class Car {
    private String carVIN;
    private String carMake;
    private int manufactureYear;

    public Car(String myVIN, String myMake, int myManuYear) {
        this.carVIN = myVIN;
        this.carMake = myMake;
        this.manufactureYear = myManuYear;
    }

    public String getCarVIN() {
        return carVIN;
    }

    public void setCarVIN(String carVIN) {
        this.carVIN = carVIN;
    }

    public String getCarMake() {
        return carMake;
    }

    public void setCarMake(String carMake) {
        this.carMake = carMake;
    }

    public int getManufactureYear() {
        return manufactureYear;
    }

    public void setManufactureYear(int manufactureYear) {
        this.manufactureYear = manufactureYear;
    }

    // *** ADDED IN, DELETE BEFORE SUBMIT
    @Override
    public String toString() {
        return "{VIN: "+ carVIN + ", Model: " + carMake + "}";
    }
}
