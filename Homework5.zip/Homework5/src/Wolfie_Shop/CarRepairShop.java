package Wolfie_Shop;
import java.util.Arrays;
// Robert Lin
// 110875190
// CSE 114
// Homework #5
public class CarRepairShop {
    private int maxSize = 100;
    private int numCars, numTickets;
    private int ticketCount; //ticket # goes up regardless of deletion (*not the actual quantity)
    private int carNumba = -1; // car # starts at 0
    private Car[] nascar = new Car[maxSize];
    private RepairTicket[] popoTicket = new RepairTicket[maxSize];

    public CarRepairShop() {
        numCars = 0;
        numTickets = 0;
    }

    public int addNewCar(String vin, String make, int year) {
        for (int i = 0; i < numCars; i++) {
            if (nascar[i].getCarVIN().equals(vin)) { // if car exists
                return -1;
            }
        }
        Car car = new Car(vin, make, year); // creates car object if car doesn't exist
        nascar[numCars] = car; // adds car to array
        numCars += 1; // adds quantity of cars
        carNumba += 1; // Car # count starting at 0
        //System.out.println("Car " + Arrays.toString(nascar)); // FOR CHECKING
        return carNumba;
    }

    public int addRepairTicket(String vin, double cost, String description) {
        for (int i = 0; i < numCars; i++) {
            if (nascar[i].getCarVIN().equals(vin)) {
                RepairTicket ticket = new RepairTicket(vin, description, cost, numTickets + 1); // creates ticket object
                popoTicket[numTickets] = ticket; // adds ticket to array
                numTickets += 1; // adds quantity of tickets
                ticketCount++; // ticket # always increases, regardless
                //System.out.println("Ticket " + Arrays.toString(popoTicket)); // FOR CHECKING
                return ticketCount;
            }
        }
        return -1; // if no car w/ given VIN exists
    }

    public double getRepairCost(int ticketNum) {
        for (int i = 0; i < numTickets; i++) {
            if (popoTicket[i].getTicketNum() == ticketNum) { // repair costs for selected ticket #
                return popoTicket[i].getRepairCost();
            }
        }
        return -1; // if ticket doesn't exist
    }

    public double getTotalRepairCosts(String vin) {
        double total = 0;
        boolean flag = false;
        for (int i = 0; i < numTickets; i++) {
            if (popoTicket[i].getRepairVIN().equals(vin) && popoTicket[i] != null) {
                total += popoTicket[i].getRepairCost();
                flag = true;
            }
        }
        if (!flag) // if car doesn't exist
            return -1;
        return total; // returns total cost for car (vin)
    }

    public String getWorstCarMake() {
        String bust = null;
        int mostRepairs = 0;
        for (int i = 0; i < numCars; i++) {
            if (nascar[i] != null) { // if not empty
                if (mostRepairs < getTotalRepairCosts(nascar[i].getCarVIN())) {
                    bust = nascar[i].getCarMake(); // sets to car model w/ most repairs
                }
            }
        }
        return bust; // will return null only if car array isn't null
    }

    public boolean updateRepairCost(int ticketNum, double newCost) {
        for (int i = 0; i < numTickets; i++) {
            if (popoTicket[i].getTicketNum() == ticketNum && popoTicket[i] != null) {
                popoTicket[i].setRepairCost(newCost); // sets to updated cost
                return true;
            }
        }
        return false; // if ticket doesn't exist
    }

    public boolean deleteRepair(int ticketNum) {
        for (int i = 0; i < numTickets; i++) {
            if (popoTicket[i].getTicketNum() == ticketNum && popoTicket[i] != null) { // gets specific ticket number
                for (int j = i; j < numTickets - 1; j++) {
                    popoTicket[j] = popoTicket[j + 1]; // copies element on the right & shifts by 1
                }
                // copies array & excludes last element to avoid duplication
                popoTicket = Arrays.copyOf(popoTicket, numTickets - 1);
                popoTicket = Arrays.copyOf(popoTicket, maxSize); // resize back to 100
                numTickets--; // reduces quantity of tickets by one
                //System.out.println("Number of tickets: " + numTickets);
                //System.out.println("Ticket " + Arrays.toString(popoTicket));
                return true;
            }
        }
        return false;
    }

    public boolean deleteAllRepairsForCar(String VIN) {
        boolean flag = false;
        int count = numTickets; // WILL BE USED for COUNTING
        RepairTicket[] heh = new RepairTicket[maxSize];
        if (numTickets > 0){
            for (int i = 0, j = 0; i < numTickets; i++) { // j = 0 for heh array
                if (popoTicket[i].getRepairVIN().equals(VIN) && popoTicket[i] != null) {
                    count--; // reduces quantity of tickets
                    continue; // goes on to the next
                }
                heh[j++] = popoTicket[i]; // adds everything BUT the selected number
            }
            heh = Arrays.copyOf(heh, numTickets - 1); // avoids duplication
            popoTicket = Arrays.copyOf(heh, maxSize); // popoTicket copies empty array heh & sets size to 100
            numTickets = count; // Sets to number of tickets remaining (quantity)
            //System.out.println("Number of tickets: " + numTickets);
            //System.out.println("Ticket " + Arrays.toString(popoTicket));
            flag = true;
        }
        return flag;
    }

    public boolean deleteCarAndRepairs(String VIN) {
        boolean flag = false;
        int count = numTickets;
        RepairTicket[] heh = new RepairTicket[maxSize];
        if (numTickets > 0) {
            for (int i = 0, j = 0; i < numTickets; i++) { // for deleting repairs
                if (popoTicket[i].getRepairVIN().equals(VIN) && popoTicket[i] != null) {
                    count--;
                    continue;
                }
                heh[j++] = popoTicket[i];
            }
            heh = Arrays.copyOf(heh, numTickets - 1); // excludes duplicate element
            popoTicket = Arrays.copyOf(heh, maxSize);
            numTickets = count; // # of tickets remaining
            //System.out.println("Number of tickets: " + numTickets);
            //System.out.println("Ticket " + Arrays.toString(popoTicket));
            flag = true;

        }

        for (int i = 0; i < numCars; i++) { // for deleting car
            if (nascar[i].getCarVIN().equals(VIN) && nascar[i] != null) {
                for (int j = i; j < numCars - 1; j++) {
                    nascar[j] = nascar[j + 1]; // copies element to the right & shifts by one
                }
                // excludes duplicate element (last)
                nascar = Arrays.copyOf(nascar, numCars - 1);
                nascar = Arrays.copyOf(nascar, maxSize); // sets to size 100
                numCars--; // THIS IS THE KEY
                //System.out.println("Number of cars: " + numCars);
                //System.out.println("Car " + Arrays.toString(nascar));
                return true; // ENDS HERE
            }
        }
        return flag;
    }
}