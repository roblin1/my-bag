package Wolfie_Shop;

public class RepairTicket {
    private String repairVIN;
    private String repairDescrip;
    private double repairCost;
    private int ticketNum;

    public RepairTicket(String myRepairVIN, String myRepairDescrip, double myRepairCost, int myTicketNum) {
        this.repairVIN = myRepairVIN;
        this.repairDescrip = myRepairDescrip;
        this.repairCost = myRepairCost;
        this.ticketNum = myTicketNum;
    }

    public String getRepairVIN() {
        return repairVIN;
    }

    public void setRepairVIN(String repairVIN) {
        this.repairVIN = repairVIN;
    }

    public String getRepairDescrip() {
        return repairDescrip;
    }

    public void setRepairDescrip(String repairDescrip) {
        this.repairDescrip = repairDescrip;
    }

    public double getRepairCost() {
        return repairCost;
    }

    public void setRepairCost(double repairCost) {
        this.repairCost = repairCost;
    }

    public int getTicketNum() {
        return ticketNum;
    }

    public void setTicketNum(int ticketNum) {
        this.ticketNum = ticketNum;
    }

    @Override
    public String toString() {
        return "{Car VIN: " + repairVIN + ", cost: " + repairCost + "}";
    }
}
