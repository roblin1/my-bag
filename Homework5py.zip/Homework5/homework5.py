"""Robert Lin"""  # your name
"roblin"  # your NetID
"110875190"  # your SBU ID number
"CSE 101"  # CSE 101
"Homework 5"  # Homework 5

from war_classes import *

# Part I
def create_deck():
    deck = []
    for j in range(4):
        for i in range(0, 13):
            deck.append(Card(i, j))
    return deck


# Part II
def deal_cards(deck):
    isPlayer1 = True
    player1 = Player(1, 0, [])
    player2 = Player(2, 0, [])
    for i in deck:
        if isPlayer1:
            player1._cards.append(i)
            isPlayer1 = False
        else:
            player2._cards.append(i)
            isPlayer1 = True
    return player1, player2


# Part III
def play_normal_round(player1, player2):
    score = 2
    player1_card = player1.draw_card()
    player2_card = player2.draw_card()
    if player1_card._rank > player2_card._rank:
        player1._score += 2
        return (1, 2)
    elif player2_card._rank > player1_card._rank:
        player2._score += 2
        return (2, 2)
    else:
        while player1_card._rank == player2_card._rank:
            if len(player1._cards) == 0 and len(player2._cards) == 0:
                return (0, 0)
            elif len(player1._cards) == 0:
                player2._score += score
                return (2, score)
            elif len(player2._cards) == 0:
                player1._score += score
                return (1, score)
            player1_card = player1.draw_card()
            player2_card = player2.draw_card()
            score += 2
        if player1_card._rank > player2_card._rank:
            player1._score += score
            return (1, score)
        else:
            player2._score += score
            return (2, score)

# Part IV
def check_game_winner(player1, player2):
    if player1._score > player2._score:
        return 1
    elif player2._score > player1._score:
        return 2
    else:
        return 0


# Part V
def play_with_suits(player1, player2):
    score = 2
    player1_card = player1.draw_card()
    player2_card = player2.draw_card()
    if player1_card._suit == 3 and (player2_card._suit == 1 or player2_card._suit == 2):
        player1._score += 2
        return (1, 2)
    elif player2_card._suit == 3 and (player1_card._suit == 1 or player1_card._suit == 2):
        player2._score += 2
        return (2, 2)
    if player1_card._suit == 1 and (player2_card._suit == 2 or player2_card._suit == 0):
        player1._score += 2
        return (1, 2)
    elif player2_card._suit == 1 and (player1_card._suit == 2 or player1_card._suit == 0):
        player2._score += 2
        return (2, 2)
    if player1_card._suit == 2 and player2_card._suit == 0:
        player1._score += 2
        return (1, 2)
    elif player2_card._suit == 2 and player1_card._suit == 0:
        player2._score += 2
        return (2, 2)
    elif player1_card._suit == 0 and player2_card._suit == 3:
        player1._score += 2
        return (1, 2)
    elif player2_card._suit == 0 and player1_card._suit == 3:
        player2._score += 2
        return (2, 2)
    else:
        while player1_card._suit == player2_card._suit:
            if len(player1._cards) == 0 and len(player2._cards) == 0:
                return (0, 0)
            elif len(player1._cards) == 0:
                player2._score += score
                return (2, score)
            elif len(player2._cards) == 0:
                player1._score += score
                return (1, score)
            player1_card = player1.draw_card()
            player2_card = player2.draw_card()
            score += 2
        if player1_card._suit == 3 and (player2_card._suit == 1 or player2_card._suit == 2):
            player1._score += score
            return (1, score)
        elif player2_card._suit == 3 and (player1_card._suit == 1 or player1_card._suit == 2):
            player2._score += 2
            return (2, score)
        if player1_card._suit == 1 and (player2_card._suit == 2 or player2_card._suit == 0):
            player1._score += 2
            return (1, score)
        elif player2_card._suit == 1 and (player1_card._suit == 2 or player1_card._suit == 0):
            player2._score += 2
            return (2, score)
        if player1_card._suit == 2 and player2_card._suit == 0:
            player1._score += 2
            return (1, score)
        elif player2_card._suit == 2 and player1_card._suit == 0:
            player2._score += 2
            return (2, score)
        elif player1_card._suit == 0 and player2_card._suit == 3:
            player1._score += 2
            return (1, score)
        elif player2_card._suit == 0 and player1_card._suit == 3:
            player2._score += 2
            return (2, score)


# Part VI
def play_with_scouts(player1, player2):
    player1_cards = []
    player2_cards = []
    player1_cards.append(player1.draw_card())
    player2_cards.append(player2.draw_card())
    normal = True
    if player1_cards[0]._rank != player2_cards[0]._rank:
        if len(player1._cards) > 0 and player1_cards[0]._rank <= 3:
            player1_cards.append(player1.draw_card())
            normal = False
        if len(player2._cards) > 0 and player2_cards[0]._rank <= 3:
            player2_cards.append(player2.draw_card())
            normal = False
    if normal == True:
        score = 2
        player1_card = player1_cards[0]
        player2_card = player2_cards[0]
        if player1_card._rank > player2_card._rank:
            player1._score += 2
            return (1, 2)
        elif player2_card._rank > player1_card._rank:
            player2._score += 2
            return (2, 2)
        else:
            player1_rank = 0
            player2_rank = 0
            while player1_card._rank == player2_card._rank:
                if len(player1._cards) == 0 or len(player2._cards) == 0:
                    return (0, 0)
                elif len(player1._cards) == 0:
                    player2._score += score
                    return (2, score)
                elif len(player2._cards) == 0:
                    player1._score += score
                    return (1, score)
                player1_card = player1.draw_card()
                player1_cards.append(player1_card)
                player2_card = player2.draw_card()
                player2_cards.append(player2_card)
                score += 2
                if len(player1._cards) > 0 and player1_card._rank <= 3:
                    player1_cards.append(player1.draw_card())
                    score = score + 1
                if len(player2._cards) > 0 and player2_card._rank <= 3:
                    player2_cards.append(player2.draw_card())
                    score = score + 1
                for card in player1_cards:
                    if card._rank >= 9:
                        player1_rank += card._rank + 2
                    else:
                        player1_rank += card._rank
                for card in player2_cards:
                    if card._rank >= 9:
                        player2_rank += card._rank + 2
                    else:
                        player2_rank += card._rank
            if player1_rank > player2_rank:
                player1._score += score
                return (1, score)
            else:
                player2._score += score
                return (2, score)
    else:
        player1_total = 0
        player2_total = 0
        if len(player1_cards) > 1:
            player1_total += 2
        if len(player2_cards) > 1:
            player2_total += 2
        for card in player1_cards:
            player1_total += card._rank
        for card in player2_cards:
            player2_total += card._rank
        score = len(player1_cards) + len(player2_cards)
        if player1_total > player2_total:
            player1._score += score
            return (1, score)
        elif player2_total > player1_total:
            player2._score += score
            return (2, score)
        else:
            while player1_total == player2_total:
                if len(player1._cards) == 0 or len(player2._cards) == 0:
                    return (0, 0)
                elif len(player1._cards) == 0:
                    player2._score += score
                    return (2, score)
                elif len(player2._cards) == 0:
                    player1._score += score
                    return (1, score)
                player1_card_new = player1.draw_card()
                player2_card_new = player2.draw_card()
                player1_cards.append(player1_card_new)
                player2_cards.append(player2_card_new)
                score += 2
                player1_total += player1_card_new._rank
                player2_total += player2_card_new._rank
                if len(player1._cards) > 0 and player1_card_new._rank <= 3:
                    player1_card_new = player1.draw_card()
                    player1_cards.append(player1_card_new)
                    player1_total += player1_card_new._rank + 2
                    score += 1
                if len(player2._cards) > 0 and player2_card_new._rank <= 3:
                    player2_card_new = player2.draw_card()
                    player2_cards.append(player2_card_new)
                    player2_total += player2_card_new._rank + 2
                    score += 1
            if player1_total > player2_total:
                player1._score += score
                return (1, score)
            elif player2_total > player1_total:
                player2._score += score
                return (2, score)
