// Robert Lin
// 110875190
// CSE 114
// Homework #7
import java.util.ArrayList;
import java.util.Arrays;

public class Homework7Methods {
    // part 1
    public static int findTimes10(int[] nums) {
        // fill this in
        return findTimes10(nums, 0);
    }

    public static int findTimes10(int[] nums, int index) {
        if (nums.length <= 1) { // base case if array length is 1
            return -1;

        } else if (index >= nums.length - 1) { // base case if reaches last index of array
            return -1;

        } else {
            if (nums[index] * 10 == nums[index + 1]) { // if [index + 1] is 10 times the value of [index]
                return index;
            } else { // moves on to next index
                return findTimes10(nums, index + 1);
            }
        }
    }

    // part 2
    public static void replaceMult5(int[] nums, int newVal) { // void method, so no need for return
        // fill this in
        replaceMult5Rec(nums, newVal, 0);
    }

    public static void replaceMult5Rec(int[] nums, int newVal, int index) {
        if (index >= nums.length) { // base case if reaches last index of array
            return;

        } else { // if divisible by 5, replace w/ newVal
            if (nums[index] % 5 == 0)
                nums[index] = newVal;
            replaceMult5Rec(nums, newVal, index + 1); // recursive call, moves on to next index
        }
    }


    // part 3     max 2 for loops!!!
    public static ArrayList<int[]> permuteArray(int[] array) {
        // fill this in
        ArrayList<int[]> answer = new ArrayList<>();

        // adds int[] array to ArrayList original
        ArrayList<Integer> original = new ArrayList<>();
        for(int i = 0; i < array.length; i++) {
            original.add(array[i]); // adds at array index
        }

        // creates a new array & prints a different permutation each recursive call
        permuteArray(new int[array.length], original, answer, 0);
        return answer;
    }

    public static void permuteArray(int[] array, ArrayList<Integer> original, ArrayList<int[]> answer, int index) {
        // when array has two "unfrozen numbers", adds the unswapped & swapped to ArrayList answer
        // ex) 47 [1 2] & 47[2 1]
        if (index == array.length - 1) { // when two "unfrozen numbers" left
            array[index] = original.get(0); // does the swapping
            answer.add(array); // adds unswapped and swapped
        }

        /* freeze the 1st number & permute the rest of the values, by "reducing array size by 1 each frozen number".
         freeze the next number too & permute the rest of the values until it reaches 2 numbers left
         once all permutations that start with the 1st number have been generated, swap the number with the next number in the ORIGINAL ARRAY {4, 7, 1, 2} */
        else {
            for (int i = 0; i < original.size(); i++) {
                int[] temp = Arrays.copyOf(array, array.length); // copies array in temp array
                temp[index] = original.get(i); // place the current selected number in the ORIGINAL array as "frozen"

                ArrayList<Integer> copy = new ArrayList<>(original); // copy original ArrayList to ArrayList copy
                copy.remove(new Integer(temp[index])); // create new ArrayList that is 1 size smaller every time number is "frozen"

                permuteArray(temp, copy, answer, index + 1); // recursive call, goes to next index
            }
        }
    }

    // part 4
    public static String[] mobius(String s1, String s2) {
        // fill this in
        String combined = s1 + s2;
        String[] result = new String[combined.length()]; // array of size (s1 + s2)
        mobius(result, combined, 0); // recursive call
        return result;
    }

    // rotates to the left
    public static void mobius(String[] answer, String str, int index) {
        if (index == str.length()) { // base case, if index reaches end of array
            return;

        } else {
            answer[index] = str; // string array stores s1 & s2
            String rotated = str.substring(1) + str.substring(0, 1); // shifts to the left by 1
            mobius(answer, rotated, index + 1); // goes back to leftRotate method again until count equals to str.length()
        }
    }

    // part 5
    public static int teddy(int initial, int goal, int increment) {
        // fill this in
        int result = -1; // fail if > 10 steps
        for (int steps = 0; steps <= 10; steps++) {
            if (teddy(initial, goal, increment, steps)) { // recursive call
                result = steps; // sets result to amount of steps to reach goal
                break;
            }
        }
        return result; // returns minimum amount of steps to reach goal
    }

    public static boolean teddy(int start, int finish, int increment, int currentStep) { // returns true will end current method
        if (start == finish) { // base case, if reached goal, done
            return true;

        } else if (currentStep == 0) { // base case if not reached goal, continue
            return false;

        } else {
                // action a = receive "increment" more bears
            if (teddy(start + increment, finish, increment, currentStep - 1)) { // action a
                return true;
                // action b = give away "increment" more bears
            } else if (teddy(start - increment, finish, increment, currentStep - 1)) { // action b
                return true;

            } else if (start % 2 == 0) { // if player has even number of bears
                    // action c = give half of your bears
                if (teddy(start - start/ 2, finish, increment, currentStep - 1)) { // action c
                    return true;
                    // action d = receive half of your bears
                } else if (teddy(start + (start / 2), finish, increment, currentStep - 1)) { // action d
                    return true;
                }
            }
        }
        return false;
    }
}