// Robert Lin
// 110875190
// CSE 214
// Timothy Barron
import java.util.NoSuchElementException;
public class DoublyLinkedList<T extends Comparable<T>> implements LinkedList<T> {

    // proper formatting is important for automated testing of your code
    // Format example:
    // head=y tail=a\ny->z->a->null\na->z->y->null
    // When printed:
    // head=y tail=a
    // y->z->a->null
    // a->z->y->null
    private Node<T> head;
    private Node<T> tail;

    public DoublyLinkedList() {
        head = null;
        tail = null;
    }

    /** adds element to front of list (head)*/
    @Override
    public void addHead(T element) {
        Node<T> newHead = new Node<T>(element);

        // if list is not empty, add head, setting left and right pointers
        if(head != null) {
            head.setPrev(newHead); // existing node is now pointing to the "added" node (left)
            newHead.setNext(head); // added node is pointing to the existing node (right)
            head = newHead; // added node is now the head
        }
        // if list is empty, set node to the head, which is also the tail (both sides)
        else {
            head = newHead;
            tail = newHead;
        }
    }

    /** adds element to end of list (tail) by traversing through the list */
    @Override
    public void addTail(T element) {
        Node<T> newTail = new Node<T>(element);

        // if list is not empty, add tail, setting right and left pointers
        if(tail != null) {
            tail.setNext(newTail); // existing node is now pointing to the "added" node (right)
            newTail.setPrev(tail); // added node is pointing to the existing node (left)
            tail = newTail; // added node is now the tail
        }
        // if list is empty, set node to the tail, which is also the head
        else {
            tail = newTail;
            head = newTail;
        }
    }

    /** removes element at the front of the list (head) */
    @Override
    public T removeHead() throws NoSuchElementException {
        T selected = head.getData(); // set Selected as the head

        // if there's only one node, remove it by setting head / tail to null
        if(head == tail) {
            head = null;
            tail = null;
            return selected; // selected is now null
        } else if(head != null) { // make the next node as the new head and delete the current head
            head = head.getNext(); // head is now the next node
            head.setPrev(null); // new head before (old head) is set to null
            return selected;
        } else { // if there's no nodes in the list, throw this exception
            throw new NoSuchElementException();
        }
    }

    /** removes element at the end of the list (tail) */
    @Override
    public T removeTail() throws NoSuchElementException {
        T selected = tail.getData(); // set Selected to the tail

        // if there's only one node, remove it by setting tail(head) to null
        if(tail == head) {
            tail = null;
            head = null;
            return selected;
        } else if(tail != null) { // make the previous node as the new tail and delete the current tail by setting it to null
            tail = tail.getPrev();
            tail.setNext(null);
            return selected;
        }
        // if there's no nodes in the list, throw this exception
        else {
            throw new NoSuchElementException();
        }
    }

    /** retrieves element at the head of the list */
    @Override
    public Node<T> getHead() {
        return this.head;
    }

    /** retrieves element at the tail of the list */
    @Override
    public Node<T> getTail() {
        return this.tail;
    }

    /** sets specified element as the head of the list */
    @Override
    public void setHead(Node<T> head) {
        this.head = head;
    }

    /** sets specified element as the tail of the list */
    @Override
    public void setTail(Node<T> tail) {
        this.tail = tail;
    }

    /** retrieves element at that particular index
     *traverse thru the linked list to get the element at that index */
    @Override
    public Node<T> get(int index) throws NoSuchElementException {
        Node<T> current = head; // set "cursor" starting at head
        int count = 0; // keeps count of the index
        while(current != null) { // as long as there is more to traverse thru
            if(count == index) { // if cursor reaches the index, return the node located at that index
                return current;
            }
            count++; // goes to next index
            current = current.getNext(); // moves the cursor to the next node
        }
        throw new NoSuchElementException();
    }

    /** adds element at this index by traversing through the list until count = index*/
    @Override
    public void add(int index, T element) throws NoSuchElementException {
        int count = 0; // counts the index
        Node<T> temp = head; // sets "cursor" starting at head
        Node<T> answer = new Node<T>(element); // node to add to list

        // if index out of bounds
        if(index < 0) {
            throw new IndexOutOfBoundsException("INVALID INPUT!");
        }

        while(temp.getNext() != null && count < index) { // until you find the correct index to add to
            if(temp == null) // if you go over the index boundaries
                throw new IndexOutOfBoundsException("INVALID INPUT!");
            temp = temp.getNext(); // goes to next node
            count++; // increase with its index
        }
        if(temp.getPrev() != null){ // connects as long as result next isn't null
            answer.setPrev(temp.getPrev()); // points left
            temp.getPrev().setNext(answer); // points right
        } else {
            head = answer; // set the head as the element
        }
        answer.setNext(temp); // points right
        temp.setPrev(answer); // points left
    }

    /** removes element at the specified index in the list by traversing through the linked list until you reach count = index */
    @Override
    public T remove(int index) throws NoSuchElementException {
        T answer; // for setting specified index to null
        Node<T> temp = head; // sets "cursor" as the head
        Node<T> prev, next; // previous and next nodes
        int count = 0;

        /** traverses until it reaches the correct index */
        while(temp.getNext() != null && count < index) {
            if(temp == null) // if you go over the index boundaries
                throw new IndexOutOfBoundsException("INVALID INPUT!");
            temp = temp.getNext(); // goes to next node
            count++; // increase the index
        }
        /** SETS THE ANSWER as that node stored in temp */
        answer = temp.getData();

        if(temp.getNext() == null) { // if no node next, remove the last node [removeTail method]
            removeTail();
        } else if(index == 0) { // if only one node, remove the head [removeHead method]
            removeHead();
        } else {
            /** removes the node at that specified index by setting "Answer" to null at the end */
            prev = temp.getPrev(); // sets previous node of temp
            next = temp.getNext();

            prev.setNext(next); // sets new pointer to the [node at the right of temp]
            next.setPrev(prev); // sets new pointer to the [node at the left of temp]
            temp.setPrev(null); // removes left pointer
            temp.setNext(null); // removes right pointer
        }
        return answer;
    }

    /** creates copy of the linked list */
    @Override
    public LinkedList<T> clone() {
        // if there are no nodes, then return null
        if(head == null)
            return null;

        // list for cloning
        DoublyLinkedList<T> clone = new DoublyLinkedList<T>();
        // store head of list as temp
        Node<T> temp = head;

        clone.head = new Node<T>(head.getData()); // copies head as a new Node
        Node copy = clone.head; // sets Node copy as the copied head

        // traversing as long as there are nodes to go to in the list
        while(temp.getNext() != null) {
            temp = temp.getNext(); // get next node
            copy.setNext(new Node<T>(temp.getData())); // set equal to next node
            copy = copy.getNext();
        }
        return clone; // returns copied Linked List
    }

    /** combines a list to the specified list by connecting the tail of the first list to the head of the list
     * you want to add to the first list */
    @Override
    public void concatenate(LinkedList<T> list) {
        if(list == null) {
            return;
        } else if (head == null) { // if list1 is empty, add list2 to it
            head = list.getHead();
            tail = list.getTail();
        } else { // connect head of list2 to tail of list1
            Node currentTail = tail;
            currentTail.setNext(list.getHead());

            // vice versa, connect tail of list1 to head of list2
            tail = list.getTail();
            list.getHead().setPrev(currentTail);
        }
    }

    /** removes all elements greater than the target argument by traversing through the list and finding duplicate numbers
     * based on the target, deleting the left and right pointers for that target*/
    // *** DOUBLE CHECK WITH WEST C
    @Override
    public void filter(T target) {
        Node<T> result = head;
        // as long as list isn't empty,
        while(result != null) {
            result = result.getNext(); // gets next node in the list

            // if node is greater than the target
            if(target.compareTo(result.getData()) == -1) {
                // if there is no next node
                if(result.getNext() == null) {
                    result.getPrev().setNext(null); // delete the duplicate node
                    tail = tail.getPrev();
                } else { // if there is a next node
                    result.getNext().setPrev(result.getPrev()); // delete right pointer
                    result.getPrev().setNext(result.getNext()); // delete left pointer
                }
            }
            // moves on to next node
            result  = result.getNext();
        }
    }

    /** insert a new node in the correct place assuming that the list is already sorted in ascending order
     * by traversing through the list and using the compareTo method to compare its value to other nodes in the list*/
    // DOUBLE CHECK THIS ONE
    @Override
    public void sortedAdd(T element) {
        Node<T> current = head;
        if(current == null) { // if list is empty, add the element by calling the addHead method
            addHead(element);
        } else if(current.getData().compareTo(element) > 0) { // if current number is greater than the element, add element by calling the set Tail method
            setTail(new Node<T>(element));
        } else { // if it's in the right place, add it and move to the next node to verify
            Node result = head;
            while (result.getNext() != null && result.getNext().getData().compareTo(element) < 0) {
                result = result.getNext();
            }
            Node<T> answer = new Node<T>(element);
            if(result.getNext() != null){ // connects as long as result next isn't null
                answer.setNext(result.getNext());
                result.getNext().setPrev(answer); // connects the 4 to the 5
            } else {
                tail = answer;
            }
            answer.setPrev(result); // connecets the 4 to the 3
            result.setNext(answer);
        }
    }

    /** sorts all the elements in ascending order using the sortedAdd method while it pops and pushes the nodes
     * into a new DoublyLinkedList*/
    @Override
    public LinkedList<T> sort() {
        Node<T> temp = head;
        DoublyLinkedList<T> hehAnswer = new DoublyLinkedList<T>();

        // if list isn't empty, call the [sortedAdd] method to put the node correctly, then move on to the next node to sortedAdd if needed
        while(temp != null) {
            hehAnswer.sortedAdd(temp.getData());
            temp = temp.getNext(); // moves on to next node
        }
        return hehAnswer; // returns new list
    }

    /** removes all the duplicates nodes */
    @Override
    public void removeDuplicates() {
        Node<T> current = head;
        // as long as list isn't empty
        while(current != null) {
            Node<T> temp = current;
            /** traverses through the list as long as the list isn't empty and node is a duplicate of another node */
            while(temp != null && temp.getData() == current.getData()) {
                temp = temp.getNext();
            }
            current.setNext(temp); // deletes right pointer of node
            current = current.getNext(); // deletes left pointer of duplicate node
        }
    }

    /** combines the lists into one list, sorting them in ascending order
     * by comparing the heads of both lists, popping them and pushing them onto a new list
     * based on whichever node is less than the other first*/
    @Override
    public LinkedList<T> merge(LinkedList<T> list) {
        // compare the heads first, pick the lower one using compareTo and add it to the merged list first
        Node<T> original = head;
        Node<T> another = list.getHead();
        DoublyLinkedList<T> newList = new DoublyLinkedList<T>(); // answer list

        // as long as neither list is empty
        while(original != null || another != null) {
            // if first list is empty, concatenate the second list to the new list
            if(original == null) {
                newList.addTail(another.getData());
                another = another.getNext();
            }
            // if second list is empty, concatenate the first list to the new list
            else if(another == null) {
                newList.addTail(original.getData());
                original = original.getNext();
            }
            // pop and push the compared nodes in order to the new list
            else {
                if(original.getData().compareTo(another.getData()) < 0) {
                    newList.addTail(original.getData()); // add tail so that it continues adding from left to right
                    original = original.getNext();
                } else {
                    newList.addTail(another.getData());
                    another = another.getNext();
                }
            }
        }
        return newList;
    }

    public String toString() {
        String s = "";

        s += "head=" + (head == null ? "null" : head.getData()) + " ";
        s += "tail=" + (tail == null ? "null" : tail.getData());
        s += "\n";
        Node<T> nodePtr = head;
        while (nodePtr != null) {
            s += nodePtr.getData() + "->";
            nodePtr = nodePtr.getNext();
        }
        s += "null";
        s += "\n";
        nodePtr = tail;
        while (nodePtr != null) {
            s += nodePtr.getData() + "->";
            nodePtr = nodePtr.getPrev();
        }
        s += "null";
        return s;
    }
}