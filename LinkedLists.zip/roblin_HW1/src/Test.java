public class Test {
    public static void main(String[] args) {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<Integer>();
        DoublyLinkedList<Integer> list1 = new DoublyLinkedList<Integer>();
        //System.out.println(list);
        list.addHead(1);
        //System.out.println(list);
        //list.addTail(5);
        //list.addTail(6);
        //list.addTail(7);
        //System.out.println(list);
        //list.add(0, 3);
        list.remove(0);
        //list.remove(1);
        //list.remove(2);
        System.out.println(list);
        //System.out.println(list.get(1).getData());
        //System.out.println(list.get(0).getData());
        //System.out.println(list.get(2).getData());
        //System.out.println(list.get(3).getData());
        //System.out.println(list.sort().merge(list1.sort()));
        //System.out.println(list);
        //list.removeHead();
        //System.out.println(list);
        //list.removeTail();
        //list.remove(3);
        //list.concatenate(list1);
        //System.out.println(list);
        //list.clone(); // CLONE WORKS
        //list.removeDuplicates();
        //System.out.println(list);
    }
}