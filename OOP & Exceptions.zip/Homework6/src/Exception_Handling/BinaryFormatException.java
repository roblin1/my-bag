package Exception_Handling;

public class BinaryFormatException extends Exception {

    public BinaryFormatException() {
        super("INVALID BINARY INPUT!"); // will execute if entered invalid binary number
    }

}