// Robert Lin
// 110875190
// CSE 114
// Homework #6
package Exception_Handling;

public class HexBinDec {
    private static final String HEX_NUMBAS = "ABCDEF";

    // hex to dec
    public static int hex2Dec(String hexString) throws HexFormatException {
        int decimal = 0;
        int digit; // digit place

        if (!hexString.matches("[0-9A-Fa-f]+")) // if invalid input
            throw new HexFormatException();

        for (int i = 0; i < hexString.length(); i++) {
            String ch = Character.toString(Character.toUpperCase(hexString.charAt(i))); // converts to uppercase letters
            if (HEX_NUMBAS.contains(ch)) { // if A - F, convert to its value 10 - 15
                digit = HEX_NUMBAS.indexOf(ch) + 10;
            } else {
                digit = Integer.parseInt(ch); // convert number string to integer value
            }
            // converts to decimal # (16^4 first, then 16^3 + 16^2 ... etc.)
            decimal += digit * Math.pow(16, ((hexString.length() - 1) - i));
        }
        return decimal;
    }

    // binary to dec
    public static int bin2Dec(String binString) throws BinaryFormatException {
        int decimal = 0;
        if (!binString.matches("[0-1]+")) // invalid input
            throw new BinaryFormatException();

        for (int i = 0; i < binString.length(); i++) {
            int digit = Integer.parseInt(Character.toString(binString.charAt(i))); // converts number string to integer value
            // converts to decimal # (2^4 first, then 2^3 + 2^2 ... etc)
            decimal += digit * Math.pow(2, ((binString.length() - 1) - i));
        }
        return decimal;
    }

    public static void main(String[] args) {
        try {
            String hexString = "Ba45F"; // 762975
            System.out.println(hexString + " to decimal: " + hex2Dec(hexString));

            hexString = "Melo07"; // invalid example
            System.out.println(hexString + " to decimal: " + hex2Dec(hexString));

        } catch (HexFormatException hfe) {
            System.out.println(hfe.getMessage());
        }

        try {
            String binString = "1011011"; // 91
            System.out.println(binString + " to decimal: " + bin2Dec(binString));

            binString = "13579"; // invalid example
            System.out.println(binString + " to decimal: " + bin2Dec(binString));

        } catch (BinaryFormatException bfe) {
            System.out.println(bfe.getMessage());
        }
    }
}