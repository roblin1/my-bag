package Exception_Handling;

public class HexFormatException extends Exception {

    public HexFormatException() {
        super("INVALID HEXADECIMAL INPUT!"); // executes if entered invalid hex number
    }
}