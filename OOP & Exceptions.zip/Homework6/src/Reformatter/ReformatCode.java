package Reformatter;

import java.util.*;
import java.io.*;

// GO TO EDIT CONFIGS under RUN tab & type file names to run UNDER "PROGRAM ARGS"
// add Test file under Homework6 folder on the top left

public class ReformatCode {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) { // two args, so != 2
            System.out.println("INVALID # OF ARGUMENTS GIVEN!");
            System.exit(1);
        }

        // creates file objects
        File file = new File(args[0]); // Test file
        File outFile = new File(args[1]); // Test2 file

        // checks if Test file as args[0] exists
        if (!file.exists()) {
            System.out.println("FILE " + args[0] + " DOES NOT EXIST!");
            System.exit(2);
        }

        // arraylist for args[0] & args[1]
        ArrayList<String> list = new ArrayList<String>();
        String list1 = "";
        String list2 = "";

        // reads text from Test file for args[0]
        try (
                // accepts input file using Scanner
                Scanner userInput = new Scanner(file);
        ) {
            // converts code to end-of-line brace style, list1 & list2 used as LINE by LINE
            list1 = userInput.nextLine();
            while (userInput.hasNext()) { // if there is more lines to read
                list2 = userInput.nextLine();

                /* if list2 (next line) contains a brace, add it to list1
                * ex) public class Test
                *     {
                *     becomes -->  public class Test {  */
                if (list2.length() > 0 && list2.charAt(list2.length() - 1) == '{') {
                    list.add(list1.concat(" {")); // adds list1 to arraylist
                    list1 = userInput.nextLine(); // reads next line
                }
                else { // if no brackets or text located, add as is to arraylist
                    list.add(list1);
                    list1 = list2; // goes to next line
                }
            }
            // if no more text to read, adds closing bracket } bc list1 contains the bracket ^
            list.add(list1);
        }

        // writes text to output file (Test2)
        try (
                PrintWriter output = new PrintWriter(outFile);
        ) {
            for (int i = 0; i < list.size(); i++) {
                output.println(list.get(i)); // prints reformatted code line by line in Test 2
                // System.out.println(list.get(i)); //PRINTS THE REFORMATTED VERSION LINE BY LINE
            }
        }
        System.out.println("FILE REFORMATTED!"); // Confirmation of reformat
    }
}