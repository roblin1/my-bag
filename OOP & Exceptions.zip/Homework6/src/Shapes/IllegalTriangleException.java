package Shapes;

class IllegalTriangleException extends Exception {
    public IllegalTriangleException() {
        super("INVALID TRIANGLE CREATED!");
    }

}
