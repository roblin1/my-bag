package Shapes;

public class ShapeTests {
    public static void main(String[] args) throws CloneNotSupportedException, IllegalTriangleException {
        double totalArea = 0;

        Octagon o1 = new Octagon(5);
        Octagon o2 = ((Octagon) o1.clone()); // copy of Octagon o1 (class cast Octagon)
        Octagon o3 = new Octagon(7);

        Triangle t1 = new Triangle(3, 4, 5);
        Triangle t2 = new Triangle(6, 8, 10);
        Triangle t3 = new Triangle(12, 16, 20);

        GeometricObject[] shapes = {o1, o2, o3, t1, t2, t3}; // array of shapes

        for (int i = 0; i < shapes.length; i++) {
            totalArea += shapes[i].getArea();
        }

        switch(o1.compareTo(o2)) {
            case 1:
                System.out.println("The area of the original Octagon is greater than the area of its clone!");
                break;

            case -1:
                System.out.println("The area of the original Octagon is less than the area of its clone!");
                break;

            case 0:
                System.out.println("The areas of the original Octagon and its clone are equal!");
                break;
        }
        System.out.println("The total area of all the geometric objects is: " + totalArea);
    }
}