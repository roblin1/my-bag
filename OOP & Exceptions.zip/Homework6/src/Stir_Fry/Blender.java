package Stir_Fry;

public class Blender extends CookingAppliance {

    public void use(String s1, String s2) {
        System.out.println("Running blender at " + s1 + " speed."); // might have to change "high"
    }

    public void clean() {
        System.out.println("Cleaning the blender.");
    }
}
