package Stir_Fry;

public abstract class CookingAppliance {

    public abstract void use(String s1, String s2); // variable # of arguments of type Object

    public abstract void clean();
}
