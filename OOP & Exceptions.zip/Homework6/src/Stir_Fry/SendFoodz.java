package Stir_Fry;

public class SendFoodz {
    public static void main(String[] args) {
        CookingAppliance a = new Blender();
        a.use("high", "");
        a.clean();

        a = new Toaster(); // polymorphism (now is a toaster)
        a.use("pizza", "low");
        a.clean();
    }
}