package Stir_Fry;

public class Toaster extends CookingAppliance {

    public void use(String s1, String s2) {
        System.out.println("Toasting food on " + s1 + " setting at " + s2 + " temperature.");
    }

    public void clean() {
        System.out.println("Cleaning the toaster.");
    }
}
