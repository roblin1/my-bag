public class CpuCore {
    // TODO
    // instance variables...
    /** while it is in that variable, it isn't in the queue; when it's put back in the queue, the Process scheduling step must be reset to NULL*/
    protected Process currentProcess; // Process variable
    protected int coreName;
    protected int limit; // the cutoff
    protected int finishedTime; // counts the step it completes at
    protected int totalTime; // total time for all the Processes
    protected int productiveStep; // counts the productive steps in doWork

    public CpuCore(int coreID, int limit) {
        // TODO
        // set up this core
        this.coreName = coreID;
        this.limit = limit;
    }

    /** whenever you enqueue, you have to set the currentStep to NULL*/
    public void step(Queue<Process> myQueue) {
        // TODO
        finishedTime++; // time stamp

        /** returns if nothing in queue and all processes are done */
        if(currentProcess == null && myQueue.isEmpty()) {
            return;
        }

        /** either CLAIM the next process to work on, give the process BACK to the queue if we reached the limit, or DO WORK on the current process */
        if(currentProcess == null && !myQueue.isEmpty()) {
            currentProcess = myQueue.dequeue(); // take another one out
        }
        else{
            if(currentProcess.getCurrentProgress() == limit) { // if not complete but reaches the limit
                myQueue.enqueue(currentProcess); // put it back in Queue
                currentProcess.setCurrentProgress(0); // set current progress to 0 as a re-setter
                currentProcess = null; // sets the Core's step to null because it's in the Queue
            } else { // if progress < limit [not complete], doWork
                doWork();
                /** if it doesn't reach the limit but it is complete */
                if(currentProcess.getProgress() == currentProcess.getSize()) {
                    currentProcess = null; // set the core's step to null bc it's done
                }
            }
        }
    }

    /** retrieves a new Process from the Queue if the Queue isn't empty*/
    private void claimProcess(Queue<Process> deQueue) {
        // TODO
        // get a new process from the queue if there is one
        if(deQueue.isEmpty())
            return;
        else {
            currentProcess = deQueue.dequeue(); // takes off the queue and puts in the step's place
        }
    }

    /** calls the doWork method in Process & prints these stats if the Process is finished */
    private void doWork() {
        // TODO
        // work on the current process

        /** calls the doWork method in Process Class */
        currentProcess.doWork();
        //System.out.println("Core: "+coreName+" Step: "+finishedTime);
        productiveStep++;

        // if it finishes the process, then print a line in the following format
        //<core id>, <process id>, <finished time>
        if(currentProcess.getProgress() == currentProcess.getSize()) {
            System.out.println("<" + coreName + ">, <" + currentProcess.getId() + ">, <" + finishedTime + ">");
            totalTime += finishedTime; // adds up the finished time of each Process
        }
    }

    // getter for productive step count
    public int getProductiveStep() {
        return productiveStep;
    }

    // checks if the Cores each has a process
    public boolean hasProcess() {
        if(currentProcess != null) {
            return true;
        } else {
            return false;
        }
    }

    // getter for total time
    public int getTotalTime() {
        return totalTime;
    }
}