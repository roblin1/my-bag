import java.util.Scanner;

public class CpuSimulator {
    private CpuCore[] cores; // array in CPUCore class holding these cores
    private Queue<Process> processQueue;

    protected int numbaProcess; // num of processes
    protected int count; // num of cores
    protected int limit; // cutoff

    public CpuSimulator(int numCores, int cutoff, Queue<Process> pq) {
        // TODO
        // set up the cores, and process queue
        // cutoff indicates maximum number of steps working on the same process
        // consecutively
        this.count = numCores;
        this.limit = cutoff;
        this.processQueue = pq;
        this.numbaProcess = processQueue.size; // stores all the number of processes for avgturnaroundtime method
        cores = new CpuCore[count]; // initialization of cores
    }

    public void run() {
        // TODO
        // loop as long as there are still processes to finish (either in the queue or
        // on a core)
        // and do one step for each core in the cpu

        boolean flag = false;

        /** creates the ID cores and its limit for each*/
        for(int i = 0; i < cores.length; i++) {
            cores[i] = new CpuCore(i, this.limit); // 0, 1, 2
        }

        /**  while all process are not finished
         * for (process to dequeue until all cores are filled up atm) */
        while(!processQueue.isEmpty() || flag) {
            flag = false;
            /** call the step method to doWork */
            for(int i = 0; i < cores.length; i++) {
                cores[i].step(processQueue);
                if(cores[i].hasProcess()) // if Core already has a process, set flag equal to true
                    flag = true;
            }
        }
    }

    /** total time of all the Processes / # of Processes */
    public int avgTurnaroundTime() {
        int totalTime = 0;
        int avgTime = 0;
        /** loop thru all the cores & its Processes to get it's totalTime */
        for(int i = 0; i < cores.length; i++) {
            totalTime += cores[i].getTotalTime();
        }
        avgTime = totalTime / numbaProcess;
        return avgTime;  // result
    }

    /** productive step is step that does work; unproductive step is step that is idle or busy swapping
    /** calculates the # of productive steps / total time */
    public double getUtilization() { // gets the Utilization factor #
        double productive = 0;
        double answer;
        double cpuTime = 0;
        /** loops thru all the cores & its Processes to add all productive steps; add all the total time of the Processes */
        for(int i = 0; i < cores.length; i++) {
            productive += cores[i].getProductiveStep();
            cpuTime += cores[i].getTotalTime();
        }
        /** # of productive steps / total time */
        answer = productive / cpuTime;
        return answer;
    }

    public static void main(String[] args) {
        // TODO

        // read the parameters from the command line using Scanner
        // first line = number of processes
        // second line = number of cores
        // third line = cutoff
        // then one line per process in this format
        // <process id>,<process size>

        // Create the process objects, set up the queue, create an instance of
        // CpuSimulator for this queue with the appropriate arguments

        /** a loop to create the characteristics of each process, then add it to the cores array */
        String identification; // use Integer.parseString
        int processSize; // size of each process
        Queue<Process> testQueue = new Queue<Process>(); // put in all the processes one by one in the queue

        Scanner user = new Scanner(System.in);
        System.out.println("Enter the number of processes: ");
        int numProcess = user.nextInt();

        System.out.println("Enter the number of cores: ");
        int numCores = user.nextInt();

        System.out.println("Enter the cutoff value: ");
        int cutVal = user.nextInt();
        user.nextLine(); // to prevent skipping the next print statement

        /** print statements for each process identification needed to add in */
        for(int i = 0; i < numProcess; i++) {
            System.out.println("Enter the Process ID and its Size in the format [process id, process size]");
            identification = user.nextLine();

            // splits String to extract the size
            String[] values = identification.split(", ");
            processSize = Integer.parseInt(values[1]); // gets the size for each process thing

            // adds the Process object to the Queue each time
            testQueue.enqueue(new Process(processSize, values[0])); // size & id
        }

        // create new object CpuSimulator
        CpuSimulator test = new CpuSimulator(numCores, cutVal, testQueue);
        test.run();
        System.out.println(test.avgTurnaroundTime());
        System.out.println(test.getUtilization());
    }
}