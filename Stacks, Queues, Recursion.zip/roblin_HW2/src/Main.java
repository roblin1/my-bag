public class Main {
    /** Uses Stack class to determine if it is a palindrome,
     * have a sorted list that keeps track of each pushed or popped off ting */

    // palindrome
    public static boolean isPalindrome(String answer) {
        String word = ""; // word used to test the String answer in reverse
        Stack<Character> result = new Stack<Character>(); //

        /** push each letter/character in the String in the Stack */
        for (int k = 0; k < answer.length(); k++) {
            result.push(answer.charAt(k));
        }

        /** as long as the Stack isn't empty, pop the letter & put it in reverse String(word) */
        while (!result.isEmpty()) {
            word = word + result.pop();
        }

        /** if String answer is equal to its reverse String word, or else return false*/
        if (answer.equals(word))
            return true;
        else
            return false;
    }

    /** 1. can insert, 2. can delete, 3. can substitute */
    public static int editDistance(String a, String b) {
        // if both strings contain no words, just return 0
        int w1 = a.length();
        int w2 = b.length();

        if (w1 == 0 && w2 == 0)
            return 0;
        // if String a contains no words, just return the length of b as the distance
        if (w1 == 0)
            return w2;
        // if String b contains no words, just return the length of a as the distance
        if (w2 == 0)
            return w1;
        /** if the first letter of the two strings are the same, recursively compare the next letter of the two strings */
        if (a.charAt(0) == b.charAt(0)) {
            return editDistance(a.substring(1), b.substring(1));
        } else {
            int insert = editDistance(a, b.substring(1)); // insert
            int remove = editDistance(a.substring(1), b); // remove
            int replace = editDistance(a.substring(1), b.substring(1)); // replace

            /** recursively find the minimum amount of steps out of all the possibilities */
            return 1 + Math.min(Math.min(insert, remove), (replace));
        }
    }

    /** recursive function that saves answers in a 2D array so each calculation only needs to occur once */
    // fast edit distance
    public static int fastEditDistance(String a, String b) {
        // if both strings contain no words, just return 0
        int w1 = a.length();
        int w2 = b.length();

        if (w1 == 0 && w2 == 0)
            return 0;
        // if String a contains no words, just return the length of b as the distance
        if (w1 == 0)
            return w2;
        // if String b contains no words, just return the length of a as the distance
        if (w2 == 0)
            return w1;
        /** if the first letter of the two strings are the same, recursively compare the next letter of the two strings */
        if (a.charAt(0) == b.charAt(0)) {
            return editDistance(a.substring(1), b.substring(1));
        } else {
            int insert = editDistance(a, b.substring(1)); // insert
            int remove = editDistance(a.substring(1), b); // remove
            int replace = editDistance(a.substring(1), b.substring(1)); // replace

            /** recursively find the minimum amount of steps out of all the possibilities */
            return 1 + Math.min(Math.min(insert, remove), (replace));
        }
    }

    // testing
    public static int mystery(int[] data, int n) {
        int sum;
        if(n <= 0)
            return 0;
        else {
            if (data[n - 1] % 2 == 0)
                sum = mystery(data, n - 1) + 1;
            else
                sum = mystery(data, n - 1);
            return sum;
        }
    }

    public static void main(String[] args) {
        // test your code here

        /** editDistance example */
        String word1 = "horse";
        String word2 = "ros";
        //System.out.println(editDistance(word1, word2));

        /** fastEditDistance example */
        //System.out.println(fastEditDistance(word1, word2));

        Stack testStack = new Stack();
        testStack.push(1);
        //testStack.push(5);
        //testStack.pop();
        //System.out.println(testStack.length());
        //System.out.println(testStack.peek());

        Queue testQueue = new Queue();
        testQueue.enqueue(5);
        testQueue.enqueue(2);
        //testQueue.dequeue();
        //System.out.println(testQueue.peek());
        //System.out.println(testQueue.isEmpty());
        //System.out.println(testQueue.length());

        /** MinStack method */
        MinStack newStack = new MinStack();
        newStack.push(5);
        newStack.push(7);
        newStack.push(4);
        newStack.push(4);
        newStack.pop();
        newStack.pop();
        //System.out.println(newStack.getMin());

        /** Palindrome example */
        String word = "racecar";
        //System.out.println(isPalindrome(word));


        /**
        // TEST 1 PREP FOR TMW
        Stack S = new Stack();
        int y = 7;
        // int x = 2;
        int x = 3;
        while(y > 0) {
            if(y % x != 0) {
                S.push(y);
            } else {
                System.out.println(S.pop());
            }
            y = y - 1;
        }

        while(!S.isEmpty()) {
            System.out.println(S.pop());
        }
         */

        int[] yes = new int[]{2, 2, 3, 3, 3, 4, 4, 4, 4};
        int n = 9;
        System.out.println(mystery(yes, n));
    }
}