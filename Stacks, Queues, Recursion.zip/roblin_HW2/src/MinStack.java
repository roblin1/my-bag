import java.util.EmptyStackException;

/** Essentially this class will have two separate Stacks, one Original Stack with all the elements
 * and one Modified Stack that contains only the minimum elements*/
public class MinStack<T extends Comparable<T>> extends Stack<T> {
    // TODO
    // instance variables...
    protected Stack<T> answerStack; // separate Stack that contains all the minimums

    public MinStack() {
        // TODO
        // set up empty min stack
        answerStack = new Stack<T>(); // initialize the separate Stack
    }

    /** retrieves the minimum element at the top of the stack
     * top of the answerStack ALWAYS contains the current minimum bc a lower # than the current min will be pushed on top of the Stack*/
    public T getMin() {
        // TODO
        // return the minimum element of the stack in O(1) time
        return answerStack.peek();
    }

    @Override
    public void push(T element) throws EmptyStackException {
        // TODO
        /** if minStack is empty, push to the original stack and modified stack
         * bc [invariable] case if modified stack is empty then original stack is empty, no need to compare yet*/
        if(answerStack.isEmpty()) {
            super.push(element);
            answerStack.push(element);
        }
        /** if minStack is not empty, then check if the # is less than or equal to the currentMin*/
        else {
            T top = answerStack.peek(); // variable to set as top of answerStack
            /** if # is less than or equal to the current min, then push that new minimum on to the original and modified Stacks*/
            if(element.compareTo(top) <= 0) {
                super.push(element);
                answerStack.push(element); // push to minimum Stack
            }
            /** if # isn't less than the current min, than just push the element in the original stack*/
            else {
                super.push(element);
            }
        }
    }

    @Override
    public T pop() throws EmptyStackException {
        // TODO
        /** if T = min = top, then pop it off
         * if not, then just pop from the original stack*/

        /** if original stack is empty, than answer stack shouldn't have any either */
        if(super.isEmpty()) {
            throw new EmptyStackException();
        }
        /** if original stack is not empty, but modified stack is empty, then pop element from the original only*/
        else if(!super.isEmpty() && answerStack.isEmpty()) {
            return super.pop();
        }
        /** if neither Stacks are empty, then check the conditions to pop from both or pop from original only*/
        else {
            /** if element is equal to the min, pop from both Stacks */
            if(super.peek().compareTo(answerStack.peek()) == 0) {
                super.pop();
                return answerStack.pop();
            }
            /** if element not equal to the min, pop from original Stack only and continue looking for the desired minimum element */
            else {
                return super.pop();
            }
        }
    }
}