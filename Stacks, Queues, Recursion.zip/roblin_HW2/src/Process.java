/** Process stores a size and an ID, the ID is used to reference it
 and the size is how long it takes to process.
 Record the work done to the process, and compare that to its size.
 If the work done is equal to the size, then the process is finished.
 Process basically just increments work done and compares it to its size. */

public class Process {
    // TODO
    // instance variables...
    protected int size; // size of Process
    protected String id; // reference for Process
    protected int progress = 0; // amount of work done to the Process
    protected int currentProgress = 0; /// current progress stuff reset back for logical reasons

    /** each Process stores a size and its ID*/
    public Process(int size, String id) {
        // TODO
        // set up process object
        this.size = size;
        this.id = id;
    }

    /** increments progress until the progress equals the size (finished)*/
    public void doWork() {
        // TODO
        // increment progress for this job

        if(progress == size)
            return;
        else {
            progress++;
            currentProgress++;
        }
        // System.out.printf(id+" %d, %d\n", getProgress(), getSize());
    }

    /** how big the process is */
    public int getSize() {
        return size;
    }

    public String getId() {
        return id;
    }

    /** amount of work done to the process */
    public int getProgress() {
        return progress;
    }

    /** amount of work done to the process while it's in the scheduling process */
    public int getCurrentProgress() {
        return currentProgress;
    }

    /** for setting progress to zero when you take the same element again to continue doing more work
     * bc limit issue if work needed to complete is 5 and limit is 3*/
    public void setCurrentProgress(int currentProgress) {
        this.currentProgress = currentProgress;
    }
}