import java.util.LinkedList;
import java.util.EmptyStackException;

/** FIFO [first in, first out] */
public class Queue<T> {
    // TODO
    // instance variables...
    protected LinkedList<T> list;
    protected int size; // size of Queue

    public Queue() {
        // TODO
        // set up empty Queue
        list = new LinkedList<T>(); // initialize LinkedList
        size = 0; // sets Queue as empty
    }

    /** increases the size of the queue and adds it to the end (top) of the queue*/
    public void enqueue(T element) {
        // TODO
        size++;
        list.addLast(element); // means add on top (end) of the queue
    }

    /** Throw exception if list is empty; else reduce the size and remove the start (bottom)*/
    public T dequeue() {
        // TODO
        if (list.isEmpty()) {
            throw new EmptyStackException();
        } else {
            size--;
            return list.removeFirst();
        }
    }

    public boolean isEmpty() {
        // TODO
        return list.size() == 0;
    }

    /** throw exception if list is empty, or else get the first element at the start (bottom)*/
    public T peek() {
        // TODO
        if(list.isEmpty())
            throw new EmptyStackException();
        else
            return list.getFirst(); // gets the same element as if it were to deQueue
    }

    public int length() {
        // TODO
        return list.size();
    }
}