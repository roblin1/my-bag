import java.util.EmptyStackException;
import java.util.LinkedList;

/** LIFO [last in, first out]*/
public class Stack<T> {
    // TODO
    // instance variables../
    protected LinkedList<T> list; // LinkedList
    protected int size; // capacity
    protected int top; // top element in Stack

    public Stack() {
        // TODO
        // set up empty stack
        list = new LinkedList<T>(); // initialize LinkedList
        top = -1; // sets Stack as empty
        size = 0; // Stack as empty
    }

    /** increases Stack size by one, and then adds the element to the top*/
    public void push(T element) throws EmptyStackException {
        // TODO
        size++; // increase size by 1 to add the element in
        list.addFirst(element);
    }

    /** If list is empty, throw exception. If list is not empty, then reduce the size and remove the top element */
    public T pop() throws EmptyStackException {
        // TODO
        if(list.isEmpty()) {
            throw new EmptyStackException();
        } else {
            size--;
            return list.removeFirst();
        }
    }

    /** throw exception if list is empty bc nothing to "look" at; else, get the top element */
    public T peek() {
        // TODO
        if(list.isEmpty()) {
            throw new EmptyStackException();
        } else {
            return list.getFirst(); // gets the same element as if it were to pop
        }
    }

    public boolean isEmpty() {
        // TODO
        return list.size() == 0;
    }

    public int length() {
        // TODO
        return list.size();
    }
}