// Robert Lin
// 110875190
// CSE 114
// Homework #8
import javafx.animation.KeyFrame;
import javafx.application.Application;
import javafx.beans.property.LongProperty;
import javafx.beans.property.SimpleLongProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.animation.Timeline;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import java.io.*;
import java.util.Scanner;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

public class Homework8 extends Application implements EventHandler<ActionEvent> {
    Button btLoad, btSave;
    TextField loadFile, saveFile;
    TextArea deWhat;
    Label word, character, time;

    public void start(Stage primaryStage) {
        word = new Label();
        character = new Label();
        time = new Label();

        btLoad = new Button("   Load File   ");
        btLoad.setStyle("-fx-border-color: black; ");
        btLoad.setFont(Font.font("Impact", 16));

        loadFile = new TextField();
        saveFile = new TextField();

        btSave = new Button("   Save File As   ");
        btSave.setStyle("-fx-border-color: black; ");
        btSave.setFont(Font.font("Impact", 16));

        deWhat = new TextArea();

        Button lower = new Button("   To Lower   ");
        lower.setStyle("-fx-border-color: black; ");
        lower.setFont(Font.font("Impact", 16));

        Button upper = new Button("   To Upper   ");
        upper.setStyle("-fx-border-color: black; ");
        upper.setFont(Font.font("Impact", 16));

        Button titleCase = new Button("   To Title Case   ");
        titleCase.setStyle("-fx-border-color: black; ");
        titleCase.setFont(Font.font("Impact", 16));

        Label findLabel = new Label("Find:");
        TextField tfFind = new TextField();
        Label replaceLabel = new Label("Replace with:");
        TextField tfReplace = new TextField();

        Button replace = new Button("   Replace All   ");
        replace.setStyle("-fx-border-color: black; ");
        replace.setFont(Font.font("Impact", 16));

        Label wordsLabel = new Label("#words:");
        Label charLabel = new Label("#chars:");
        Label secLabel = new Label("Seconds since last save:");

        GridPane gridPane = new GridPane();
        gridPane.setPrefSize(1000, 500);
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(5);
        gridPane.setHgap(5);
        gridPane.setAlignment(Pos.CENTER); // grid alignment

        gridPane.add(btLoad, 0, 0);
        gridPane.add(loadFile, 1, 0,2,1);
        gridPane.add(btSave, 3, 0);
        gridPane.add(saveFile, 4, 0);
        gridPane.add(deWhat, 0, 1, 6, 6);
        gridPane.add(lower,0,10);
        gridPane.add(upper, 1, 10);
        gridPane.add(titleCase, 2, 10);
        gridPane.add(findLabel,0,11);
        gridPane.add(tfFind,1,11,2,1);
        gridPane.add(replaceLabel,3, 11);
        gridPane.add(tfReplace,4,11);
        gridPane.add(replace,5,11);
        gridPane.add(wordsLabel,0,12);
        gridPane.add(word,1,12); // # words
        gridPane.add(charLabel, 2, 12);
        gridPane.add(character,3,12); // # characters
        gridPane.add(secLabel,4,12);
        gridPane.add(time,5,12); // #seconds

        deWhat.setOnMouseClicked(e -> { // clicking on it will give values
            int count = deWhat.getText().split("\\s+").length; // word count!
            word.setText(Integer.toString(count));

            int deCount = deWhat.getText().length();  // character count
            character.setText(Integer.toString(deCount));
        });

        btLoad.setOnAction(event -> {  // loads the selected file
            if(loadFile.getText().equals("")) {
                Alert loadingError = new Alert(AlertType.ERROR);
                loadingError.setTitle("Error");
                loadingError.setHeaderText("Error");
                loadingError.setContentText("File not found.");
                loadingError.showAndWait();
            } else {
                deWhat.clear(); // clears TextArea contents before loading
                String fileName = loadFile.getText();
                File file = new File(fileName);
                Scanner fileReader;
                try {
                    fileReader = new Scanner(file);
                    while (fileReader.hasNextLine()) {
                        deWhat.appendText(fileReader.nextLine()); // prints into text area
                        deWhat.appendText("  \n"); // prints on next line
                    }
                } catch(FileNotFoundException fnfe){
                    Alert loadingError = new Alert(AlertType.ERROR);
                    loadingError.setTitle("Error");
                    loadingError.setHeaderText("Error");
                    loadingError.setContentText("File not found.");
                    loadingError.showAndWait();
                }
            }
        });

        btSave.setOnAction(event -> { // saves the selected file
            if (saveFile.getText().equals("")) {
                Alert savingError = new Alert(AlertType.ERROR);
                savingError.setTitle("Error");
                savingError.setHeaderText("Error");
                savingError.setContentText("File could not be written.");
                savingError.showAndWait();
            } else {
                String fileName = saveFile.getText();
                File file = new File(fileName);
                try {
                    FileOutputStream out = new FileOutputStream(file, true);
                    out.write(deWhat.getText().getBytes()); // writes to text area

                } catch (IOException ie) {
                    Alert savingError = new Alert(AlertType.ERROR);
                    savingError.setTitle("Error");
                    savingError.setHeaderText("Error");
                    savingError.setContentText("File could not be written.");
                    savingError.showAndWait();
                }

                // KEEPS TRACK OF TIME
                LongProperty myTime = new SimpleLongProperty(0);
                Timeline timeline = new Timeline(new KeyFrame(Duration.millis(1000), e -> {
                    myTime.set(myTime.get() + 1); // every one second
                    time.setText(Long.toString(myTime.longValue())); // UPDATES TIME IN THE LOOP!
                }));
                timeline.setCycleCount(Timeline.INDEFINITE);
                timeline.play();
            }
        });

        lower.setOnAction(event -> { // lowercase (void method)
            String daLow = deWhat.getText().toLowerCase();
            deWhat.setText(daLow);
        });

        upper.setOnAction(event -> { // uppercase
            String daUp = deWhat.getText().toUpperCase();
            deWhat.setText(daUp);
        });

        titleCase.setOnAction (event -> { // capitalizes 1st word in TextArea
            String daTitle = deWhat.getText().toLowerCase().trim(); // make all lowercase
            String result = daTitle.substring(0, 1).toUpperCase() + daTitle.substring(1);
            deWhat.setText(result); // final result [THIS WHOLE SECTION WORKS]
        });

        replace.setOnAction(event -> { // replace text
            String before = tfFind.getText();
            String after = tfReplace.getText();
            deWhat.setText(deWhat.getText().replaceAll(before, after));
        });

        // *** SETS UP & DISPLAYS EVERYTHING ON THE SCREEN ***
        Scene scene = new Scene(gridPane);
        primaryStage.setTitle("Homework 8 Extra Credit Assignment");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void handle(ActionEvent event) {}

    public static void main(String[] args){
        launch(args);
    }
}