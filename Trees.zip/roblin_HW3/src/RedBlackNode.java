import java.security.InvalidParameterException;

public class RedBlackNode<K extends Comparable<K>, V> extends TreeNode<K, V> {
    // red node if this is true, black if false
    private boolean red;

    // default to red
    public RedBlackNode(K key, V value) {
        super(key, value);
        red = true;
    }

    // can take a string to set color
    // this makes things a little easier when testing
    public RedBlackNode(K key, V value, String color) {
        super(key, value);
        if (color.equalsIgnoreCase("black"))
            setBlack();
        else if (color.equalsIgnoreCase("red"))
            setRed();
        else
            throw new InvalidParameterException("color must be red or black");
    }

    public boolean isRed() {
        return red;
    }

    public boolean isBlack() {
        return !red;
    }

    public void setRed() {
        this.red = true;
    }

    public void setBlack() {
        this.red = false;
    }

    public RedBlackNode<K, V> getLeft() {
        return (RedBlackNode<K, V>) left;
    }

    public RedBlackNode<K, V> getRight() {
        return (RedBlackNode<K, V>) right;
    }

    public RedBlackNode<K, V> getParent() {
        return (RedBlackNode<K, V>) parent;
    }

    @Override
    public String toString() {
        return "TreeNode [red=" + red + ", " + "key=" + getKey() + ", value=" + getValue() + "]";
    }

    /** determines if the tree rooted at this node satisfies all the properties of a Red-Black tree */
    /** 1. every node in the tree is either RED or BLACK
     * 2. root of tree is black
     * 3. red node can't have red parent or child
     * 4. every path from node to any descendant nodes includes the same # of Black nodes */
    public Boolean isRedBlackTree() {
        // TODO

        RedBlackNode<K, V> root = this;

        while(root.getParent() != null)
            root = root.getParent();

        /** 2. return FALSE if root of tree is not black */
        if(!root.isBlack())
            return false;

        // calls and checks these helper methods
        return validateRedProperty(this) && verifyBlackLength(depth());
    }

    /** 3. checks if red node has a red parent or child */
    private Boolean validateRedProperty(RedBlackNode<K, V> node) {
        if(node == null) // returns TRUE if there is no node
            return true;

        /** if node is red: */
        if(node.isRed()) {
            if(node.getLeft() != null && node.getRight() != null) { // recursive call the next left & right nodes if there are children
                if(node.getLeft().isBlack() && node.getRight().isBlack())
                    return validateRedProperty(node.getLeft()) && validateRedProperty(node.getRight());
            }
            else if(node.getLeft() != null && node.getRight() == null) { // recursive call the next left node if there is no right node
                if(node.getLeft().isBlack()) // if left node is black
                    return validateRedProperty(node.getLeft());
            }
            else if(node.getLeft() == null && node.getRight() != null) { // recursive call the next right node if there is no left node
                if(node.getRight().isBlack()) // if right node is black  [DIFFERENCE BETWEEN THIS AND NODE
                    return validateRedProperty(node.getRight());
            } // ELSE WHAT IF THERE ARE BOTH NULL???
            else
                return node.getLeft() == null && node.getRight() == null;
        }

        /** if node is black and is simpler bc it doesn't matter if children are black or red */
        else {
            if(node.getLeft() != null && node.getRight() != null) { // recursive call the next left & right nodes if there are children
                return validateRedProperty(node.getLeft()) && validateRedProperty(node.getRight());
            }
            else if(node.getLeft() != null && node.getRight() == null) { // recursive call the next left node if there is no right node
                return validateRedProperty(node.getLeft());
            }
            else if(node.getLeft() == null && node.getRight() != null) { // recursive call the next right node if there is no left node
                return validateRedProperty(node.getRight());
            }
            else
                return node.getLeft() == null && node.getRight() == null;
        }

        return false; // return FALSE if one of the child nodes is black
    }

    /** for counting the depth of BLACK NODES */
    public int depth() {
        /** if there is no next node, the depth is 0 */
        if(this.getLeft() == null && this.getRight() == null) {
            if(this.isBlack())
                return 0;
            return -1;
        }

        else if(this.getLeft() != null && this.getRight() == null) {
            if(this.isBlack())
                return 1 + this.getLeft().depth();
            return this.getLeft().depth();
        }

        else if(this.getLeft() == null && this.getRight() != null) {
            if (this.isBlack())
                return 1 + this.getRight().depth();
            return this.getRight().depth();
        }

        /** if there is a left & right node, depth is 1 plus the depth of the left OR 1 plus the depth of the right, whichever is LONGER */
        else {
            if(this.isBlack())
                return 1 + Math.max(this.getLeft().depth(), this.getRight().depth());
            return Math.max(this.getLeft().depth(), this.getRight().depth());
        }
    }

    private boolean verifyBlackLength(int length) {
        /** return FALSE if length is less than zero */
        if(length < -1) {
            return false;
        }

        /** if the node has no children, return TRUE if length is zero, FALSE otherwise */
        else if(this.getLeft() == null && this.getRight() == null) {
            /** RIGHT NOT CROSS */
            if(isBlack() && length == 0) { // check if black & root is 0 (black)
                return true;
            } else if(!isBlack() && length == -1) { // check if isn't black & root is -1 (red)
                return true;
            } else {
                return false;
            }
        }

        /** if the node only has a left child, return TRUE if length is zero and if the left child PASSES with length minus one, FALSE otherwise */
        else if(getLeft() != null && getRight() == null) {
            /** count the black node w/ (length - 1) */
            if(isBlack()) {
                if(length == 0 && getLeft().verifyBlackLength(length - 1)) {
                    return true;
                } else {
                    return false;
                }
            }
            else { /** don't count if node is red (length) */
                if(length == -1 && getLeft().verifyBlackLength(length)) { // length is -1 bc don't count red
                    return true;
                } else {
                    return false;
                }
            }
        }

        /** if the node only has a right child, return TRUE if length is zero and if the right child PASSES with length minus one, FALSE otherwise */
        else if(getRight() != null && getLeft() == null) {
            /** count the black node w/ (length - 1) which is used as a count */
            if(isBlack()) {
                if(length == 0 && getRight().verifyBlackLength(length - 1)) {
                    return true;
                } else {
                    return false;
                }
            } else { /** don't count if node is red (length), not (length - 1) */
                if(length == -1 && getRight().verifyBlackLength(length)) { // length is -1 bc don't count red
                    return true;
                } else {
                    return false;
                }
            }
        }

        /** if the node is BLACK and has children, return TRUE if both children PASS with length minus one, FALSE if either one of the children FAILS with length minus one */
        else if(isBlack()) { // return TRUE if left and right have equal # of nodes
            boolean rightChildPasses = getRight().verifyBlackLength(length - 1); // false
            boolean leftChildPasses = getLeft().verifyBlackLength(length - 1); // false
            return rightChildPasses && leftChildPasses;
        }

        /** if the node is RED and has children, return TRUE if both children PASS with length, FALSE if either one of the children FAILS with length */
        else { // return TRUE is left and right have equal # of nodes
            boolean rightChildPasses = getRight().verifyBlackLength(length);
            boolean leftChildPasses = getLeft().verifyBlackLength(length);
            return rightChildPasses && leftChildPasses;
        }
    }
}