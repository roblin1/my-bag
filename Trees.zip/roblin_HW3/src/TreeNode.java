public class TreeNode<K extends Comparable<K>, V> {

    // pointers shared with subclasses
    protected TreeNode<K, V> left;
    protected TreeNode<K, V> right;
    protected TreeNode<K, V> parent;
    private K key; // integer value ex) 1, 2, 3
    private V value; // varChar value ex) A, B, C

    public TreeNode(K key, V value) {
        this.key = key;
        this.value = value;
        left = null;
        right = null;
        parent = null;
    }

    public TreeNode<K, V> getLeft() {
        return left;
    }

    public void setLeft(TreeNode<K, V> node) {
        node.setParent(this); // connect the node to its parent
        this.left = node; // set node as left node
    }

    public TreeNode<K, V> getRight() {
        return right;
    }

    public void setRight(TreeNode<K, V> node) {
        node.setParent(this);
        this.right = node;
    }

    public TreeNode<K, V> getParent() {
        return parent;
    }

    public void setParent(TreeNode<K, V> parent) {
        this.parent = parent;
    }

    /** returns key value */
    public K getKey() {
        return key;
    }

    public void setKey(K key) {
        this.key = key;
    }

    /** returns value of node (not key value) */
    public V getValue() {
        return value;
    }

    public void setValue(V value) {
        this.value = value;
    }

    public String printSubTree() {
        StringBuilder buffer = new StringBuilder(50);
        print(buffer, "", "");
        return buffer.toString();
    }

    /** method that prints the appearance of the TreeNode */
    private void print(StringBuilder buffer, String prefix, String childrenPrefix) {
        buffer.append(prefix);
        buffer.append(this.toString());
        buffer.append('\n');

        if (left != null) {
            if (right != null) {
                left.print(buffer, childrenPrefix + "├──left| ", childrenPrefix + "│   ");
            } else {
                left.print(buffer, childrenPrefix + "└──left| ", childrenPrefix + "    ");
            }
        }
        if (right != null) {
            right.print(buffer, childrenPrefix + "└──right| ", childrenPrefix + "    ");
        }
    }

    @Override
    public String toString() {
        return "TreeNode [key=" + key + ", value=" + value + "]";
    }

    /** returns node's uncle or null if it doesn't have one */
    public TreeNode<K, V> getUncle() {
        // TODO

        /** if the node's parent's parent's left child is not equal to the node's parent, then return the uncle */
        if(this.getParent().getParent().getLeft() != this.getParent())
            return this.getParent().getParent().getLeft();

        /** if the node's parent's parent's right child is not equal to the node's parent, then return the uncle */
        if(this.getParent().getParent().getRight() != this.getParent())
            return this.getParent().getParent().getRight();

        return null;
    }

    /** returns the NEXT node that would be visited by an IN-ORDER traversal or null if there is no NEXT node
     * IN-ORDER : LEFT --> ROOT --> RIGHT */

    /** We’re looking for the next node to be visited after this one. Since this node would have been
     visited already, that means we would have also already finished visiting all of the left sub-tree. (THINK: left --> root --> right)

     If the given node has a right child then we should look in the right sub-tree and the next node
     in-order will be the farthest left node in that tree which you can find by going left as many times
     as many times as possible.

     If the given node has no right child, then this entire subtree is finished and the next node is an
     ancestor. If we’re in a right sub-tree then the parent was visited before so we keep going up
     until we are in a left-subtree in which case the next thing to visit is the parent. If you do this and
     never find a parent to visit then the node we started at was the end of a traversal. */
    public TreeNode<K, V> nextInOrder() {
        // TODO

        TreeNode<K, V> currentNode = this; // store the selected node in currentNode

        /** if n has a right child, then return the leftmost child of the right subtree (go right then left repeatedly until null) */
        if(currentNode.getRight() != null) {
            currentNode = currentNode.getRight(); // go right
            while(currentNode.getLeft() != null) { // keep going left until there's no more left node
                currentNode = currentNode.getLeft();
            }
            return currentNode;
        }

        /** if n doesn't have a right child, then find remaining ancestors to visit */
        else {
            if(currentNode.getParent() != null) {
                while(currentNode == currentNode.getParent().getRight()) { // while n is a right child of its parent,
                    currentNode = currentNode.getParent(); // then go up the tree
                    if(currentNode.getParent() == null) // if n is the root bc there is no parent, then return null
                        return null;
                }
            }
            return currentNode.getParent(); // returns the root
        }
    }

    /** determines if the tree rooted at this node is a binary search tree
     * the left subtree contains nodes w/ keys LESS than the node's key
     * the right subtree contains nodes w/ keys GREATER than the node's key */
    public boolean isBST() {
        // TODO

        TreeNode<K,V> min = this;
        TreeNode<K,V> max = this;

        /** as long as there is a left node, keep going left and store it as the minimum */
        while(min.getLeft() != null)
            min = min.getLeft();

        /** as long as there is a right node, keep going right and store it as the maximum */
        while(max.getRight() != null)
            max = max.getRight();

        return validateBST(this, min.getKey(), max.getKey()); // calls helper method
    }

    /** compares the values of the nodes to validate the properties of a BST */
    private boolean validateBST(TreeNode<K, V> node, K min, K max) {
        /** if tree is empty, return TRUE bc it is a BST */
        if(node == null)
            return true;

        /** return FALSE if node is less than the left node (min) or if node is greater than the right node (max) */
        if((node.getKey().compareTo(min) < 0) || (node.getKey().compareTo(max) > 0)) {
            return false;
        }

        /** if no properties are violated, then recursively check for the next nodes if there are more nodes */

        /** if only has left child, recursively call & compare the NEWER left w/ the last right child */
        if(node.getLeft() != null && node.getRight() == null)
            return validateBST(node.getLeft(), min, node.getKey()); // (newer left, new min, same max(right))

        /** if only has right child, recursively call & compare the last left w/ the NEWER right child */
        else if(node.getLeft() == null && node.getRight() != null)
            return validateBST(node.getRight(), node.getKey(), max); // (newer right, same min(left), new max)

        /** if has both children, recursively call & compare using the combos of both methods above */
        else if(node.getLeft() != null && node.getRight() != null)
            return validateBST(node.getLeft(), min, node.getKey()) && validateBST(node.getRight(), node.getKey(), max);

        return true; // if no children, return true
    }
}