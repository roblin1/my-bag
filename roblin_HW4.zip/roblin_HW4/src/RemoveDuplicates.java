/** Robert Lin
 * 110875190
 * CSE 214
 * Timothy Barron */

import java.util.*;

class RemoveDuplicates {

    /** uses an iterator and a hash-map to compare if there are duplicates:
     * 1. if there is a duplicate in the hash-map, remove from the iterator
     * 2. if there is no duplicate, put value from iterator into the hashmap */
    public static void removeDuplicates(LinkedList<Integer> data) {
        ListIterator<Integer> myList = data.listIterator(0); // int index 0

        HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

        /** while there are more values in the Linked List */
        while(myList.hasNext()) {
            Integer selected = myList.next(); // store next value in type Integer

            /** if map already has this number, remove from the main list [no need to remove from map bc not put it in at all] */
            if(map.get((selected)) != null) {
                myList.remove();
            }

            /** if map doesn't contain the duplicate number already */
            else {
                map.put(selected, selected); // key, value is the same
            }
        }
    }

    public static void main(String[] args) {
        // EXAMPLE TEST
        //int[] arr = { 6, 8, 3, 5, 7, 32, 6, 8, 3, 2, 3, 6, 1, 32 };

        LinkedList<Integer> arr = new LinkedList<Integer>(Arrays.asList(6, 8, 3, 5, 7, 32, 6, 8, 3, 2, 3, 6, 1, 32));
        // System.out.println("Linked list: " + arr);

        removeDuplicates(arr);
        // arr is now {6, 8, 3, 5, 7, 32, 2, 1}
         for (int x : arr)
            // // System.out.println(x);

            //my modified
             System.out.print(x + " ");
    }
}