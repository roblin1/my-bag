/** Robert Lin
 * 110875190
 * CSE 214
 * Timothy Barron */

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.time.MovingAverage;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.ui.ApplicationFrame;
import javax.swing.*;
import java.awt.*;

class SortingComparison extends ApplicationFrame {
    // use this for counting comparisons done by a sort
    // a global variable is not ideal, but we can use this for every sort without
    // worrying about return types for now
    // remember to reset it to 0 before sorting
    /** GLOBAL VARIABLE that counts # of comparisons */
    private int comparisons;

    public SortingComparison(final String title) {

        super(title);

        // Collections that hold the series we are about to create
        final XYSeriesCollection divAndConqData = new XYSeriesCollection();
        final XYSeriesCollection quadraticData = new XYSeriesCollection();

        int maxSize = 5000;
        int dataRange = 1000;

        final XYSeries series1 = new XYSeries("quick sort k=0");
        // quick sort with no insertion sort
        // loop from 0 to maxSize
        // create an array of each size and fill it with random elements using
        // (int) (Math.random() * dataRange)
        // sort using the method for this series
        // add data point to series like series1.add(size, comparisons);
        // ...
        // ...
        // ...
        // after adding all the data points, (there should be maxSize of them) add the
        // series to the collection for this graph

        /** for (index till max size)
         *      initialize new array
         *      for (index1 till its array length)
         *          input random values into index
         *      sorting algorithm
         *      add in coordinates(size of current array, comparisons from sorting method)
         * .addSeries */

        int[] array1;
        for(int i = 0; i < maxSize; i++) {
            array1 = new int[i];
            for(int k = 0; k < array1.length; k++) {
                array1[k] = (int) (Math.random() * dataRange);
            }
            quickSort(array1);
            series1.add(array1.length, comparisons);
        }
        divAndConqData.addSeries(series1);

        final XYSeries series2 = new XYSeries("quick sort k=10");
        // repeat above for quick sort with insertion sort for 10 or less elements
        int[] array2;
        for(int i = 0; i < maxSize; i++) {
            array2 = new int[i];
            for(int k = 0; k < array2.length; k++) {
                array2[k] = (int) (Math.random() * dataRange);
            }
            hybridQuickSort(array2, 10);
            series2.add(array2.length, comparisons);
        }
        divAndConqData.addSeries(series2);

        final XYSeries series3 = new XYSeries("quick sort k=20");
        // repeat above...
        int[] array3;
        for(int i = 0; i < maxSize; i++) {
            array3 = new int[i];
            for(int k = 0; k < array3.length; k++) {
                array3[k] = (int) (Math.random() * dataRange);
            }
            hybridQuickSort(array3, 20);
            series3.add(array3.length, comparisons);
        }
        divAndConqData.addSeries(series3);

        final XYSeries series4 = new XYSeries("quick sort k=50");
        // repeat above...
        int[] array4;
        for(int i = 0; i < maxSize; i++) {
            array4 = new int[i];
            for(int k = 0; k < array4.length; k++) {
                array4[k] = (int) (Math.random() * dataRange);
            }
            hybridQuickSort(array4, 50);
            series4.add(array4.length, comparisons);
        }
        divAndConqData.addSeries(series4);

        final XYSeries series5 = new XYSeries("merge sort");
        // reminder: merge sort with out-of-place merge so that we get O(n log n)
        // runtime
        // repeat above
        int[] array5;
        for(int i = 0; i < maxSize; i++) {
            array5 = new int[i];
            for(int k = 0; k < array5.length; k++) {
                array5[k] = (int) (Math.random() * dataRange);
            }
            mergeSort(array5);
            series5.add(array5.length, comparisons);
        }
        divAndConqData.addSeries(series5);

        // max size for quadratic sorts. we needs these to be smaller so that it doesn't
        // take too long
        maxSize = 500;
        final XYSeries series6 = new XYSeries("insertion sort");
        // repeat above...

        // adding to a different graph for quadratic sort, but the process is the same
        int[] array6;
        for(int i = 0; i < maxSize; i++) {
            array6 = new int[i];
            for(int k = 0; k < array6.length; k++) {
                array6[k] = (int) (Math.random() * dataRange);
            }
            insertionSort(array6, array6.length);
            series6.add(array6.length, comparisons);
        }
        quadraticData.addSeries(series6);

        final XYSeries series7 = new XYSeries("selection sort");
        // repeat above...
        int[] array7;
        for(int i = 0; i < maxSize; i++) {
            array7 = new int[i];
            for(int k = 0; k < array7.length; k++) {
                array7[k] = (int) (Math.random() * dataRange);
            }
            selectionSort(array7, array7.length);
            series7.add(array7.length, comparisons);
        }
        quadraticData.addSeries(series7);

        final XYSeries series8 = new XYSeries("bubble sort");
        // repeat above...
        int[] array8;
        for(int i = 0; i < maxSize; i++) {
            array8 = new int[i];
            for(int k = 0; k < array8.length; k++) {
                array8[k] = (int) (Math.random() * dataRange);
            }
            bubbleSort(array8, array8.length);
            series8.add(array8.length, comparisons);
        }
        quadraticData.addSeries(series8);

        // YOU DON'T REALLY NEED TO TOUCH THIS SECTION, BUT FEEL FREE TO LOOK THROUGH IT
        // =============================================================================================================
        // takes the data sets and turns them into a moving average so things are easier
        // to see
        XYDataset ma1 = MovingAverage.createMovingAverage(divAndConqData, "", 50, 0);
        XYDataset ma2 = MovingAverage.createMovingAverage(quadraticData, "", 50, 0);
        // takes the moving averages and plots them as line charts
        // if you want to see what it looks like without the moving average you can put
        // data1 and data2 directly in here instead of ma1 and ma2
        final JFreeChart chart1 = ChartFactory.createXYLineChart("Divide and conquer sorts", "Input size n",
                "Num comparisons", ma1, PlotOrientation.VERTICAL, true, true, false);
        final JFreeChart chart2 = ChartFactory.createXYLineChart("Quadratic sorts", "Input size n", "Num comparisons",
                ma2, PlotOrientation.VERTICAL, true, true, false);
        // panel/window setup
        // don't worry about this unless you want to mess with dimensions
        final ChartPanel chartPanel1 = new ChartPanel(chart1);
        final ChartPanel chartPanel2 = new ChartPanel(chart2);
        chartPanel1.setPreferredSize(new java.awt.Dimension(400, 270));
        chartPanel2.setPreferredSize(new java.awt.Dimension(400, 270));
        JPanel j = new JPanel();
        j.setLayout(new GridLayout());
        j.add(chartPanel1);
        j.add(chartPanel2);
        setContentPane(j);
        // =============================================================================================================
    }

    public void selectionSort(int[] data, int n) { // n is the size of the array
        comparisons = 0; // reset back to 0
        int i, j, minLocation;
        for(i = 0; i <= n - 2; i++) {
            /** find the minimum element in the unsorted array */
            minLocation = i;
            for(j = i + 1; j <= n - 1; j++) {
                /** values are being compared */
                comparisons++;
                if (data[j] < data[minLocation]) {
                    minLocation = j;
                }
            }
            /** swap the found minimum element with the first element */
            int temp = data[minLocation];
            data[minLocation] = data[i];
            data[i] = temp;
        }
        System.out.println("Selection sort: # of Comparisons: " + comparisons);
    }

    public void insertionSort(int[] data, int n) {
        comparisons = 0; // reset back to 0
        int i, j, item;
        for(i = 1; i <= n - 1; i++) {
            item = data[i];
            j = i;
            /** move elements of data[index], that are greater than key,
             * to one position ahead of their current position */
            while(j > 0 && data[j - 1] > item) {
                data[j] = data[j - 1];
                /** values are being compared when elements are greater than key */
                comparisons++; // when loop condition is true
                j--;
            }
            /** values are being compared but don't have to move the elements because it's sorted correctly */
            comparisons++; // when loop condition is false
            data[j] = item;
        }
        System.out.println("Insertion sort: # of Comparisons: " + comparisons);
    }

    public void bubbleSort(int[] data, int n) {
        comparisons = 0; // reset back to 0
        int i, j;
        for(i = 0; i <= n - 2; i++) {
            for (j = n - 1; j > i; j--) {
                /** values are being compared */
                comparisons++;
                if (data[j] < data[j - 1]) {
                    /** if element to the right is less than the element to the left, swap */
                    int temp = data[j];
                    data[j] = data[j - 1];
                    data[j -1] = temp;
                }
            }
        }
        System.out.println("Bubble sort: # of Comparisons: " + comparisons);
    }

    /** main method for Merge Sort that takes in the array and resets comparisons to 0 */
    public void mergeSort(int[] data) {
        comparisons = 0; // reset to 0
        mergeSort(data, 0, data.length - 1);
        System.out.println("Merge sort: # of Comparisons: " + comparisons);
    }

    /** helper method that sorts the array using the merge() function */
    public void mergeSort(int[] data, int first, int last) {
        if (last - first > 0) {
            /** find the middle point */
            int mid = first + (last - first) / 2;

            /** recursive calls to sort the first and second halves of the array */
            mergeSort(data, first, mid);
            mergeSort(data, mid + 1, last);

            /** call to combine the sorted halves */
            merge(data, first, mid, last);
        }
    }

    /** method that merges the two sub-arrays */
    public void merge(int[] data, int first, int mid, int last) {
        /** sizes of left and right sub-arrays to be merged */
        int left = mid - first + 1;
        int right = last - mid;

        /** temp arrays for the left and right sub-arrays */
        int[] leftSide = new int[left];
        int[] rightSide = new int[right];

        /** copy the data elements to the left & right sub-arrays */
        for (int i = 0; i < left; i++)
            leftSide[i] = data[first + i];

        for (int j = 0; j < right; j++)
            rightSide[j] = data[mid + 1 + j];

        /** Merge the temp arrays */
        // initial indexes of first and second sub-arrays
        int index1 = 0;
        int index2 = 0;

        // initial index for merged array
        int mergeIndex = first;
        while (left > index1 && right > index2) { // while the indexes do not reach the bounds [not index out of bounds]
            comparisons++; // values to be compared
            /** if values of left array are less than or equal to values of right array, add the values of the left to the merged array */
            if (leftSide[index1] <= rightSide[index2]) {
                data[mergeIndex] = leftSide[index1];
                index1++;

                /** if values of right array are greater than the values of left array, add the values of the right to the merged array */
            } else {
                data[mergeIndex] = rightSide[index2];
                index2++;
            }
            mergeIndex++;
        }

        /** copies the remaining elements from left sub-array to merged array if there are any */
        while (left > index1) {
            data[mergeIndex] = leftSide[index1];
            index1++;
            mergeIndex++;
        }

        /** copies the remaining elements from right sub-array to merged array if there are any */
        while (right > index2) {
            data[mergeIndex] = rightSide[index2];
            index2++;
            mergeIndex++;
        }
    }

    /** main method for Quick Sort that takes in the array and resets comparisons to 0 */
    public void quickSort(int[] data) {
        comparisons = 0; // so it doesn't reset every time recursive is called
        quickSort(data, 0, data.length - 1);
        System.out.println("Quick sort: # of Comparisons: " + comparisons);
    }

    /** helper method that sorts the array by partitioning certain pieces of the array */
    public void quickSort(int[] data, int first, int last) {
        if(last - first > 0) {
            int pivotIndex = partition(data, first, last);
            /** recursively sort elements before partition and after partition */
            quickSort(data, first, pivotIndex - 1);
            quickSort(data, pivotIndex + 1, last);
        }
    }

    /** takes the first element as the pivot, places the pivot element at its correct position in the sorted array
     * and places all the smaller (smaller than pivot) to left of the pivot, and all greater elements to right of pivot */
    private int partition(int[] data, int first, int last) {
        /** pick a pivot to be the first element and leave it there for now */
        int pivot = data[first];
        int left = first + 1; // index of smaller element
        int right = last; // index of larger element

        /** while there are more elements to sort through */
        while(left < right) {
            comparisons++; // compare the values

            /** search left to right until we find something greater than the pivot */
            while(data[left] < pivot && left < right) {
                left++;
                comparisons++; // compare the values
            }
            /** search right to left until we find something less or equal to pivot */
            while(data[right] >= pivot && left < right) {
                right--;
                comparisons++; // compare the values
            }

            /** if left index is greater than the right index, swap the values of that of the left with that of the right */
            if(left < right) {
                int temp = data[right];
                data[right] = data[left];
                data[left] = temp;
            }
        }
        /** make sure the element to be swapped with pivot belongs to the left */
        if(data[left] >= pivot)
            left--;
        // swap pivot to its location
        data[first] = data[left];
        data[left] = pivot;
        return left; // return the location of the pivot
    }

    /** main method for Hybrid Quick sort that takes in the array and k value */
    public void hybridQuickSort(int[] data, int k) {
        comparisons = 0; // resets to 0
        hybridQuickSort(data, 0, data.length - 1, k);
        System.out.println("Hybrid Quick sort: # of Comparisons: " + comparisons);
    }

    /** helper method that sorts the array by partitioning certain pieces of the array */
    public void hybridQuickSort(int[] data, int first, int last, int k) {
        if(last - first > 0) {
            /** if the size of the current portion of the array is greater than k, then continue partitioning and recursively calling quickSort */
            if(last - first > k) {
                // comparisons++;
                int pivotIndex = partition(data, first, last);
                /** recursively sort elements before partition and after partition */
                hybridQuickSort(data, first, pivotIndex - 1, k);
                hybridQuickSort(data, pivotIndex + 1, last, k);
            }
            /** if the size of the current portion of the array is less than or equal to k, then call insertion sort instead of quick sort */
            else {
                // comparisons++;
                /** calls insertion sort */
                insertSort(data, data.length);
            }
        }
    }

    /** same as above Insertion Sort except without the comparisons reset to 0 */
    public void insertSort(int[] data, int n) {
        // comparisons = 0;
        int i, j, item;
        for(i = 1; i <= n - 1; i++) {
            item = data[i];
            j = i;
            while(j > 0 && data[j - 1] > item) {
                data[j] = data[j - 1];
                comparisons++; // compares the values when the loop condition is true
                j--;
            }
            comparisons++; // compares the values when the loop condition is false
            data[j] = item;
        }
    }

    public static void main(String[] args) {
        // EXAMPLE TESTS

//         int[] arr1 = { 1, 2, 3, 4, 5, 6, 7 };
//         sort(arr1, 0, arr1.length - 1, 5);
//         for (int x: arr1)
//         System.out.println(x);
//         System.out.println();

        SortingComparison test = new SortingComparison(" name of sort ");
        /** bubble and selection sort # of comparisons should be the same */

//         int[] arr2 = { 7, 6, 5, 4, 3, 2, 1};
//         test.hybridQuickSort(arr2, 0, arr2.length - 1, 5);
//         for (int x: arr2)
//         System.out.println(x);
//         System.out.println();
//
//         int[] arr3 = { 56, 3, 78, 26, 1276, 123, 45, 34};
//         test.hybridQuickSort(arr3, 0, arr3.length - 1, 5);
//         for (int x: arr3)
//         System.out.println(x);
//         System.out.println();

        int[] pob = {64, 44, 99, 55, 11, 88, 22, 77, 33, 13};
        test.selectionSort(pob, 10); // size, not last index
//        for (int x: pob)
//            System.out.print(x + " ");
//        System.out.println();
        //System.out.println("Selection sort: # of Comparisons: " + test.comparisons); 45

        int[] pob1 = {64, 44, 99, 55, 11, 88, 22, 77, 33, 13};
        test.insertionSort(pob1,10);
//        for (int x: pob1)
//            System.out.print(x + " ");
//        System.out.println();
        //System.out.println("Insertion sort: # of Comparisons: " + test.comparisons); 38

        int[] pob2 = {10,9,8,7,6,5,4,3,2,1};
        test.bubbleSort(pob2, 10);
//        for (int x: pob2)
//            System.out.print(x + " ");
//        System.out.println();
        //System.out.println("Bubble sort: # of Comparisons: " + test.comparisons); 45

        int[] pob3 = {64, 44, 99, 55, 11, 88, 22, 77, 33, 13};
        test.mergeSort(pob3);
//        for (int x: pob3)
//            System.out.print(x + " ");
//        System.out.println();
        //System.out.println("Merge sort: # of Comparisons: " + test.comparisons); 23

        int[] pob4 = {64, 44, 99, 55, 11, 88, 22, 77, 33, 13};
        test.quickSort(pob4);
//        for (int x: pob4)
//            System.out.print(x + " ");
//        System.out.println();
        //System.out.println("Quick sort: # of Comparisons: " + test.comparisons); 21

        int[] pob5 = {64, 44, 99, 55, 11, 88, 22, 77, 33, 13};
        test.hybridQuickSort(pob5, 5);
//        for (int x: pob5)
//            System.out.print(x + " ");
//        System.out.println();
        // System.out.println("Hybrid Quick sort: # of Comparisons: " + test.comparisons); 9

        // call constructor for our ApplicationFrame which will set up all the test
        // sorts and plot the results
        final SortingComparison window = new SortingComparison("Sorting comparison");
        window.pack();
        window.setVisible(true);
    }
}