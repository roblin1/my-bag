import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

class Graph<T> {

    private HashMap<T, Vertex<T>> verticesList; // hash-map for vertices
    private int verticesCount; // counts # of vertices
    private int edgesCount; // counts # of edges

    /** initializes an empty graph */
    public Graph() {
        verticesList = new HashMap<T, Vertex<T>>();
        verticesCount = 0;
        edgesCount = 0;
    }

    /** initializes a graph from the specified file name
     * takes in the filename of a .dot file, reads its content, & creates the corresponding graph */
    public Graph(String filename) throws FileNotFoundException {
        /** takes in everything initialized in Graph constructor above */
        this();

        List<String> lines;
        /** reads file */
        try {
            Scanner user = new Scanner(new File(filename));
            lines = new ArrayList<String>();
            while(user.hasNextLine()) {
                lines.add(user.nextLine());
            }
        }
        catch (Exception e) {
            throw new FileNotFoundException("SELECTED FILE DOESN'T EXIST!");
        }

        /** removes the first and last lines (diagraph {   }) */
        lines.remove(0);
        lines.remove(lines.size() - 1);

        /** creates the graph */
        for(int i = 0; i < lines.size(); i++) {
            String[] store = lines.get(i).split("->");
            String first = store[0].trim();
            String second = store[1].trim();
            this.addEdge((T) first, (T) second);
        }
    }

    /** added in to check if selected T is a vertex */
    public boolean isVertex(T name) {
        return verticesList.containsKey(name);
    }

    /** creates vertices if they don't exist & connects them to an edge */
    public void addEdge(T x, T y) {
        /** store vertices X & Y in Vertex variables */
        Vertex<T> v1 = verticesList.get(x);
        Vertex<T> v2 = verticesList.get(y);

        /** if edge already exists between the two points */
        if (isEdge(x, y)) {
            return;
        }

        /** if edge doesn't already exist, increment edgeCount & verticesCount, and adds edge */
        edgesCount++;
        if (v1 == null) { // creates Vertex if it doesn't already exist
            v1 = new Vertex<T>(x);
            verticesList.put(x, v1); // place vertex in the Hashmap
            verticesCount++;
        }

        if (v2 == null) {
            v2 = new Vertex<T>(y);
            verticesList.put(y, v2);
            verticesCount++;
        }

        verticesList.get(x).getNeighbors().add(y); // places edge in the Hashmap
        verticesList.get(y).getRvsNeighbors().add(x);
    }

    /** removes edge by accessing its neighbors and remove its neighbor, or essentially the "edge" connecting the two vertices */
    public void removeEdge(T x, T y) {
        if(isEdge(x, y)) {
            LinkedList<T> neighbors = verticesList.get(x).getNeighbors();
            neighbors.remove(y);

            LinkedList<T> rvsNeighbors = verticesList.get(y).getRvsNeighbors();
            rvsNeighbors.remove(x);
            edgesCount--;
        }
    }

    public boolean isEdge(T x, T y) {
        /** if either x or y vertex doesn't exist, there is no edge connecting them */
        if (!isVertex(x) || !isVertex(y))
            return false;

        return verticesList.get(x).getNeighbors().contains(y);
    }

    /** 1. copy hashmap values to the created linked list
     * 2. if x doesn't exist, throw exception
     * 3. if x exists but has no neighbors (can't traverse), return empty list
     * 4. if x exists and has neighbors, traverse and return list with its neighbors
     * outgoing neighbors (a --> b), b is the outgoing one */
    public LinkedList<T> neighbors(T x) {
        if (!verticesList.containsKey(x)) { // throw exception is x doesn't exist
            throw new IllegalArgumentException("Vertex doesn't Exist!");
        } else { // if x exists but has no neighbors
            LinkedList<T> list = verticesList.get(x).getNeighbors();
            return list;
        }
    }

    /** returns # of vertices */
    public int numVertices() {
        return verticesCount;
    }

    /** returns # of edges */
    public int numEdges() {
        return edgesCount;
    }

    /** throw exception if vertex doesn't exist
     * if vertex exists, then remove the edges connecting to the vertex and the vertex itself */
    public void removeVertex(T x) {
        if(!verticesList.containsKey(x)) {
            throw new NoSuchElementException("VERTEX DOESN'T EXIST!");
        } else {
            for(int i = 0; i < verticesList.get(x).getNeighbors().size(); i++)
                removeEdge(x, verticesList.get(x).getNeighbors().get(i));

            for(int j = 0; j < verticesList.get(x).getRvsNeighbors().size(); j++)
                removeEdge(verticesList.get(x).getRvsNeighbors().get(j), x);

            verticesList.remove(x);
            verticesCount--;
        }
    }

    /** takes a filename for a .dot file and writes the current state of the graph object out to DOT file
     * in the same format it was read */
    public void toDotFile(String filename) throws IOException {
        List<String> result = new ArrayList<String>();
        /** looks into verticeslist which looks into individual vertices which looks into the edges that each vertex is connected to
         // tea is the neighbor (Vertex) */
        for(T key: verticesList.keySet()) {
            for(T tea: verticesList.get(key).getNeighbors()) {
                result.add("   " + key + "->" + tea);
            }
        }
        result.add(0, "diagraph { ");
        result.add("}");

        /** writes to a new file after it is done reading */
        FileWriter writer = new FileWriter(filename);
        for(String str: result) {
            writer.write(str + System.lineSeparator());
        }
        writer.close();}

    /** helper function that is a modified version of the lecture slides that uses Hashmap <T, Boolean> and T parameter */
    public void dfsHelper(T v, HashMap<T, Boolean> marked) {
        Vertex<T> result = verticesList.get(v);
        Boolean yes = Boolean.TRUE;
        LinkedList<T> connections = result.getNeighbors();
        int i;
        T nextNeighbor;
        marked.put(v, yes); // tests each thingy

        System.out.println(result.getLabel());
        for(i = 0; i < connections.size(); i++) {
            nextNeighbor = connections.get(i);
            if(!marked.get(nextNeighbor))
                dfsHelper(nextNeighbor, marked);
        }
    }

    public void depthFirstSearch(T x) {
        HashMap<T, Boolean> marked = new HashMap<T, Boolean>();
        for(T key: verticesList.keySet())
            marked.put(key, Boolean.FALSE);
        dfsHelper(x, marked);
    }

    /** function that is a modified version of the lecture slides that uses Hashmap <T, Boolean> and T parameter */
    public void breadthFirstSearch(T x) {
        LinkedList<T> connections;
        int i;
        T vertex, nextNeighbor;
        Queue<T> q = new Queue<T>();

        HashMap<T, Boolean> marked = new HashMap<T, Boolean>();
        for(T key: verticesList.keySet())
            marked.put(key, Boolean.FALSE);

        marked.put(x, Boolean.TRUE);
        q.enqueue(x);
        while(!q.isEmpty()) {
            vertex = q.dequeue();
            System.out.println(vertex);
            connections = verticesList.get(vertex).getNeighbors();
            for(i = 0; i < connections.size(); i++) {
                nextNeighbor = connections.get(i);
                if(!marked.get(nextNeighbor)) {
                    marked.put(nextNeighbor, Boolean.TRUE);
                    q.enqueue(nextNeighbor);
                }
            }
        }
    }

    /** helper function that is a modified version of the lecture slides that uses Hashmap <T, Boolean> and T parameter
     * USES A STACK instead of a QUEUE */
    public void depthFirstSearchIterative(T x) {
        LinkedList<T> connections;

        int i;
        T vertex, nextNeighbor;
        Stack<T> s = new Stack<T>();

        HashMap<T, Boolean> marked = new HashMap<T, Boolean>();
        for(T key: verticesList.keySet())
            marked.put(key, Boolean.FALSE);

        marked.put(x, Boolean.TRUE);
        s.push(x);
        while(!s.isEmpty()) {
            vertex = s.pop();
            System.out.println(vertex);
            connections = verticesList.get(vertex).getNeighbors();
            for(i = 0; i < connections.size(); i++) {
                nextNeighbor = connections.get(i);
                if(!marked.get(nextNeighbor)) {
                    marked.put(nextNeighbor, Boolean.TRUE);
                    s.push(nextNeighbor);
                }
            }
        }
    }

    /** used for main method to help visualize what graph looks like when it's ran */
    public void printGraph() {
        for(T key: verticesList.keySet()) {
            for(T tea: verticesList.get(key).getNeighbors()) {
                System.out.println(key + "->" + tea);
            }
        }
    }

    public static void main(String[] args) {
        Graph g;
        try {
            g = new Graph("C:\\Users\\blade\\IntellijProjects\\roblin_HW5\\heh.dot"); // filename size
        }
        catch (Exception e){
            System.out.println("Fatal Error, crashing now.");
            e.printStackTrace();
            System.out.println("Fatal Error, crashing now.");
            return;
        }
        g.addEdge("A", "B");
        g.addEdge("B", "D");
        g.addEdge("C", "E");
        g.addEdge("E", "B");

        g.removeEdge("A", "B");
        g.removeEdge("F", "S");

        g.removeVertex("C");

        try {
            g.toDotFile("C:\\Users\\blade\\IntellijProjects\\roblin_HW5\\hehpart2.dot");
        } catch (Exception ex) {
            System.out.println("Fatal Error, crashing now.");
            ex.printStackTrace();
            System.out.println("Fatal Error, crashing now.");
            return;
        }

        g.printGraph();
    }
}