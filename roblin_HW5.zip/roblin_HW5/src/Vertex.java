import java.util.LinkedList;

class Vertex<T> {
    private T label;
    private double weight;
    private LinkedList<T> neighbors;

    /** for counting neighbors the other way (like an undirected graph) */
    private LinkedList<T> reverseNeighbors;

    public Vertex(T label) {
        setLabel(label);
        setNeighbors(new LinkedList<T>());

        setRvsNeighbors(new LinkedList<T>());
        setWeight(1);

    }

    public T getLabel() {
        return label;
    }

    public void setLabel(T label) {
        this.label = label;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public LinkedList<T> getNeighbors() {
        return neighbors;
    }

    public void setNeighbors(LinkedList<T> neighbors) {
        this.neighbors = neighbors;
    }

    public LinkedList<T> getRvsNeighbors() {
        return reverseNeighbors;
    }

    public void setRvsNeighbors(LinkedList<T> reverseNeighbors) {
        this.reverseNeighbors = reverseNeighbors;
    }
}